<?php
/**
 * Global helpers for the Eventin - Tutor LMS bridge.
 */

defined( 'ABSPATH' ) || exit;

/**
 * Whether the addon is toggled on from the Eventin Extensions page.
 *
 * Eventin core stores per-extension state in wp_options['etn_addons_options']
 * keyed by extension slug. Treats missing key as off (matches Extension.php
 * default `status => 'off'` for this addon).
 *
 * @return bool
 */
function eventin_tutor_addon_enabled() {
    $opts = get_option( 'etn_addons_options', array() );
    return isset( $opts['eventin-addon-for-tutor-lms'] )
        && 'on' === $opts['eventin-addon-for-tutor-lms'];
}

/**
 * Get an addon option from the wp_options blob.
 *
 * @param string $key
 * @param mixed  $default
 * @return mixed
 */
function eventin_tutor_get_option( $key = '', $default = false ) {
    $opts = get_option( 'eventin_tutor_lms_options', array() );

    if ( '' === $key ) {
        return $opts;
    }

    return isset( $opts[ $key ] ) ? $opts[ $key ] : $default;
}

/**
 * Update a single addon option.
 *
 * @param string $key
 * @param mixed  $value
 * @return bool
 */
function eventin_tutor_update_option( $key, $value ) {
    $opts         = get_option( 'eventin_tutor_lms_options', array() );
    $opts[ $key ] = $value;
    return update_option( 'eventin_tutor_lms_options', $opts );
}

/**
 * Read the saved ticket->course mapping for an event.
 *
 * Map shape:  [ 'ticket_slug' => [ course_id_1, course_id_2 ] ].
 *
 * @param int $event_id
 * @return array
 */
function eventin_tutor_get_ticket_course_map( $event_id ) {
    $map = get_post_meta( (int) $event_id, '_eventin_tutor_ticket_course_map', true );
    return is_array( $map ) ? $map : array();
}

/**
 * Save the ticket->course mapping for an event.
 *
 * @param int   $event_id
 * @param array $map
 * @return void
 */
function eventin_tutor_save_ticket_course_map( $event_id, array $map ) {
    update_post_meta( (int) $event_id, '_eventin_tutor_ticket_course_map', $map );
}

/**
 * Whether Tutor LMS integration is enabled for the given event.
 *
 * Backward-compat: events saved before the toggle existed have no
 * `_eventin_tutor_enabled` meta. If they have a non-empty mapping, treat
 * them as enabled so existing enrollment flows don't silently break.
 *
 * @param int $event_id
 * @return bool
 */
function eventin_tutor_get_event_enabled( $event_id ) {
    $event_id = (int) $event_id;
    $raw      = get_post_meta( $event_id, '_eventin_tutor_enabled', true );

    if ( '' === $raw || null === $raw ) {
        $map = eventin_tutor_get_ticket_course_map( $event_id );
        return ! empty( $map );
    }

    return '1' === (string) $raw || 1 === $raw || true === $raw;
}

/**
 * Persist the per-event Tutor LMS integration toggle.
 *
 * @param int  $event_id
 * @param bool $enabled
 * @return void
 */
function eventin_tutor_save_event_enabled( $event_id, $enabled ) {
    update_post_meta( (int) $event_id, '_eventin_tutor_enabled', $enabled ? '1' : '0' );
}

/**
 * Return the ticket variations defined on an Eventin event.
 *
 * @param int $event_id
 * @return array
 */
function eventin_tutor_get_event_tickets( $event_id ) {
    $tickets = get_post_meta( (int) $event_id, 'etn_ticket_variations', true );
    return is_array( $tickets ) ? $tickets : array();
}

/**
 * Resolve the list of Tutor LMS course IDs mapped to a given ticket on an event.
 *
 * @param int    $event_id
 * @param string $ticket_slug
 * @return int[]
 */
function eventin_tutor_courses_for_ticket( $event_id, $ticket_slug ) {
    $map = eventin_tutor_get_ticket_course_map( $event_id );

    $course_ids = array();
    if ( $ticket_slug && isset( $map[ $ticket_slug ] ) ) {
        $course_ids = (array) $map[ $ticket_slug ];
    }

    $course_ids = array_filter( array_map( 'absint', $course_ids ) );

    /**
     * Filter the resolved course IDs for an event/ticket pair.
     *
     * @since 1.0.0
     *
     * @param int[]  $course_ids
     * @param int    $event_id
     * @param string $ticket_slug
     */
    return apply_filters( 'eventin_tutor_lms_courses_for_ticket', $course_ids, $event_id, $ticket_slug );
}
