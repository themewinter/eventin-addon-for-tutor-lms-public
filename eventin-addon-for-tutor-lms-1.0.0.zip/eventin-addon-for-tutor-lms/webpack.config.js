/**
 * Webpack configuration for the Tutor LMS addon.
 *
 * Extends @wordpress/scripts default config. Uses webpack externals to
 * resolve antd and @emotion/styled from the parent Eventin plugin's
 * window.eventin globals, keeping the addon bundle small (~7 KiB instead
 * of ~520 KiB).
 *
 * IMPORTANT: The addon script depends on 'etn-packages' (set in
 * core/assets/enqueue.php) which ensures window.eventin.antd,
 * window.eventin.styled, etc. are available before this bundle executes.
 */

const defaultConfig = require( '@wordpress/scripts/config/webpack.config' );

module.exports = {
	...defaultConfig,
	externals: {
		...defaultConfig.externals,
		antd: [ 'window', 'eventin', 'antd' ],
		'@ant-design/icons': [ 'window', 'eventin', 'antdIcons' ],
		'@emotion/styled': [ 'window', 'eventin', 'styled' ],
	},
};
