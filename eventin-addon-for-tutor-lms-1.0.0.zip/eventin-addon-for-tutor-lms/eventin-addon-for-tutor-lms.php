<?php
/**
 * Plugin Name:       Eventin Addon for Tutor LMS
 * Description:       Auto-enrolls Eventin ticket buyers (and registered attendees) into mapped Tutor LMS courses.
 * Version:           1.0.0
 * Requires at least: 5.6
 * Requires PHP:      7.4
 * Requires Plugins:  Eventin, tutor
 * Author:            Arraytics
 * Author URI:        https://themewinter.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       eventin-addon-for-tutor-lms
 * Domain Path:       /languages
 *
 * @package Eventin_Tutor
 * @category Core
 * @author  Arraytics
 * @version 1.0.0
 */

use Eventin_Tutor\Eventin_Tutor;
use Eventin_Tutor\Providers\Global_Service_Provider;

defined( 'ABSPATH' ) || exit;

$eventin_tutor_autoload = __DIR__ . '/vendor/autoload.php';

if ( ! file_exists( $eventin_tutor_autoload ) ) {
    add_action( 'admin_notices', function () {
        if ( ! current_user_can( 'activate_plugins' ) ) {
            return;
        }
        echo '<div class="notice notice-error"><p>'
            . esc_html__( 'Eventin - Tutor LMS Integration is missing its Composer autoloader (vendor/autoload.php). Run "composer install" inside the plugin directory.', 'eventin-addon-for-tutor-lms' )
            . '</p></div>';
    } );
    return;
}

require_once $eventin_tutor_autoload;

defined( 'EVENTIN_TUTOR_FILE' )    || define( 'EVENTIN_TUTOR_FILE', __FILE__ );
defined( 'EVENTIN_TUTOR_DIR' )     || define( 'EVENTIN_TUTOR_DIR', __DIR__ );
defined( 'EVENTIN_TUTOR_VERSION' ) || define( 'EVENTIN_TUTOR_VERSION', '1.0.0' );

global $eventin_tutor_container;

$eventin_tutor_container = new \Eventin_Tutor\Container\Container();
$eventin_tutor_container->add_service_provider( 'global', Global_Service_Provider::class );

/**
 * Eventin Tutor container accessor.
 *
 * @return \Eventin_Tutor\Container\Container
 */
function eventin_tutor_container() {
    global $eventin_tutor_container;
    return $eventin_tutor_container;
}

/**
 * Dependency check. Eventin + Tutor LMS must be active.
 *
 * @return bool
 */
function eventin_tutor_dependencies_met() {
    $eventin_active = class_exists( 'Wpeventin' )
        || class_exists( '\Etn\Core\Order\OrderModel' )
        || defined( 'EVENTIN_PLUGIN_FILE' );

    $tutor_active = function_exists( 'tutor' )
        || function_exists( 'tutor_utils' );

    return ( $eventin_active && $tutor_active );
}

/**
 * Show admin notice if Eventin or Tutor LMS is missing.
 *
 * @return void
 */
function eventin_tutor_dependency_notice() {
    if ( eventin_tutor_dependencies_met() ) {
        return;
    }
    echo '<div class="notice notice-error"><p>'
        . esc_html__( 'Eventin - Tutor LMS Integration requires both Eventin and Tutor LMS to be installed and active.', 'eventin-addon-for-tutor-lms' )
        . '</p></div>';
}

/**
 * Boot the plugin once all plugins are loaded.
 *
 * @return Eventin_Tutor|null
 */
function eventin_tutor() {
    add_action( 'admin_notices', 'eventin_tutor_dependency_notice' );

    if ( ! eventin_tutor_dependencies_met() ) {
        return null;
    }

    if ( ! eventin_tutor_addon_enabled() ) {
        return null;
    }

    return Eventin_Tutor::instance();
}

add_action( 'plugins_loaded', 'eventin_tutor', 20 );
