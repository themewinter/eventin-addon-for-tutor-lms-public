<?php
/**
 * REST module service provider.
 *
 * @package Eventin_Tutor/Rest
 */

namespace Eventin_Tutor\Rest;

defined( 'ABSPATH' ) || exit;

use Eventin_Tutor\Providers\Base_Service_Provider;

class Rest_Service_Provider extends Base_Service_Provider {

    /**
     * @var array
     */
    protected $services = array(
        Mapping_Controller::class,
        Event_Save_Bridge::class,
    );

    public function get_services() {
        return apply_filters( 'eventin_tutor_rest_services', $this->services );
    }
}
