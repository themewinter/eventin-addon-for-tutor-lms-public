<?php
/**
 * REST controller — namespace `eventin-addon-for-tutor-lms/v1`.
 *
 *   GET  /events/{id}/mapping   → current mapping + ticket variations for the event
 *   POST /events/{id}/mapping   → persist mapping
 *   GET  /courses               → Tutor LMS course list for the picker
 *   GET  /diagnostics           → tutor_active flag, course count, edit URLs
 *
 * The React mapping card consumes all three on mount.
 *
 * @package Eventin_Tutor/Rest
 */

namespace Eventin_Tutor\Rest;

defined( 'ABSPATH' ) || exit;

use Eventin_Tutor\Contracts\Hookable_Service_Contract;
use WP_Error;
use WP_REST_Request;
use WP_REST_Server;

class Mapping_Controller implements Hookable_Service_Contract {

    const NAMESPACE_V1     = 'eventin-addon-for-tutor-lms/v1';
    const EVENT_POST_TYPE  = 'etn';

    /**
     * Register hooks.
     *
     * @return void
     */
    public function register() {
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
    }

    /**
     * Register REST routes.
     *
     * @return void
     */
    public function register_routes() {
        register_rest_route(
            self::NAMESPACE_V1,
            '/events/(?P<id>[\d]+)/mapping',
            array(
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array( $this, 'get_mapping' ),
                    'permission_callback' => array( $this, 'permissions_check_event' ),
                    'args'                => array(
                        'id' => array(
                            'type'     => 'integer',
                            'required' => true,
                        ),
                    ),
                ),
                array(
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => array( $this, 'save_mapping' ),
                    'permission_callback' => array( $this, 'permissions_check_event' ),
                    'args'                => array(
                        'id'      => array(
                            'type'     => 'integer',
                            'required' => true,
                        ),
                        'mapping' => array(
                            'type'     => 'object',
                            'required' => true,
                        ),
                    ),
                ),
            )
        );

        register_rest_route(
            self::NAMESPACE_V1,
            '/courses',
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_courses' ),
                'permission_callback' => array( $this, 'permissions_check_courses' ),
            )
        );

        register_rest_route(
            self::NAMESPACE_V1,
            '/diagnostics',
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_diagnostics' ),
                'permission_callback' => array( $this, 'permissions_check_courses' ),
            )
        );
    }

    /**
     * Per-event authorization for /events/{id}/mapping (GET + POST).
     * Mirrors the meta-box save check: the caller must be able to edit
     * the specific event whose mapping is being read or written.
     *
     * @param WP_REST_Request $request
     * @return bool|WP_Error
     */
    public function permissions_check_event( WP_REST_Request $request ) {
        $event_id = (int) $request['id'];

        if ( ! $event_id || self::EVENT_POST_TYPE !== get_post_type( $event_id ) ) {
            return new WP_Error(
                'eventin_tutor_invalid_event',
                __( 'Invalid event id.', 'eventin-addon-for-tutor-lms' ),
                array( 'status' => 404 )
            );
        }

        if ( ! current_user_can( 'edit_post', $event_id ) ) {
            return new WP_Error(
                'rest_forbidden',
                __( 'You are not allowed to manage the mapping for this event.', 'eventin-addon-for-tutor-lms' ),
                array( 'status' => rest_authorization_required_code() )
            );
        }

        return true;
    }

    /**
     * Authorization for /courses and /diagnostics. Requires Eventin event
     * management AND the capability to edit the course post type — so that
     * draft/private/future course rows are not exposed to users who cannot
     * already see them in the WP admin.
     *
     * @return bool|WP_Error
     */
    public function permissions_check_courses() {
        if ( ! current_user_can( 'etn_manage_event' ) && ! current_user_can( 'manage_options' ) ) {
            return new WP_Error(
                'rest_forbidden',
                __( 'You are not allowed to access course data.', 'eventin-addon-for-tutor-lms' ),
                array( 'status' => rest_authorization_required_code() )
            );
        }

        $pto      = get_post_type_object( $this->get_course_post_type() );
        $edit_cap = ( $pto && isset( $pto->cap->edit_posts ) ) ? $pto->cap->edit_posts : 'edit_posts';

        if ( ! current_user_can( $edit_cap ) ) {
            return new WP_Error(
                'rest_forbidden',
                __( 'You are not allowed to access course data.', 'eventin-addon-for-tutor-lms' ),
                array( 'status' => rest_authorization_required_code() )
            );
        }

        return true;
    }

    /**
     * GET /events/{id}/mapping
     *
     * @param WP_REST_Request $request
     * @return array|WP_Error
     */
    public function get_mapping( WP_REST_Request $request ) {
        $event_id = (int) $request['id'];

        if ( ! $event_id || 'etn' !== get_post_type( $event_id ) ) {
            return new WP_Error( 'eventin_tutor_invalid_event', __( 'Invalid event id.', 'eventin-addon-for-tutor-lms' ), array( 'status' => 404 ) );
        }

        $tickets = eventin_tutor_get_event_tickets( $event_id );
        $simple_tickets = array();
        foreach ( $tickets as $ticket ) {
            $simple_tickets[] = array(
                'name' => isset( $ticket['etn_ticket_name'] ) ? (string) $ticket['etn_ticket_name'] : '',
                'slug' => isset( $ticket['etn_ticket_slug'] ) ? (string) $ticket['etn_ticket_slug'] : '',
            );
        }

        return rest_ensure_response( array(
            'event_id' => $event_id,
            'tickets'  => $simple_tickets,
            'mapping'  => (object) eventin_tutor_get_ticket_course_map( $event_id ),
            'enabled'  => eventin_tutor_get_event_enabled( $event_id ),
        ) );
    }

    /**
     * POST /events/{id}/mapping
     *
     * Body: { "mapping": { "ticket-slug": [ course_id, ... ], ... } }
     *
     * @param WP_REST_Request $request
     * @return array|WP_Error
     */
    public function save_mapping( WP_REST_Request $request ) {
        $event_id = (int) $request['id'];

        if ( ! $event_id || 'etn' !== get_post_type( $event_id ) ) {
            return new WP_Error( 'eventin_tutor_invalid_event', __( 'Invalid event id.', 'eventin-addon-for-tutor-lms' ), array( 'status' => 404 ) );
        }

        $raw   = (array) $request->get_param( 'mapping' );
        $clean = array();

        foreach ( $raw as $ticket_slug => $course_ids ) {
            $ticket_slug = sanitize_key( $ticket_slug );
            $course_ids  = array_filter( array_map( 'absint', (array) $course_ids ) );

            if ( '' !== $ticket_slug && ! empty( $course_ids ) ) {
                $clean[ $ticket_slug ] = array_values( $course_ids );
            }
        }

        eventin_tutor_save_ticket_course_map( $event_id, $clean );

        /** This action is documented in core/admin/meta-box.php */
        do_action( 'eventin_tutor_lms_after_save_mapping', $event_id, $clean );

        return rest_ensure_response( array(
            'event_id' => $event_id,
            'mapping'  => (object) $clean,
            'success'  => true,
        ) );
    }

    /**
     * GET /courses — flat list for the picker.
     *
     * Public statuses are always returned; non-public ones (draft/private/
     * pending/future) only when the caller can already read private posts of
     * the course post type. Authorization is also enforced by the route's
     * permission_callback.
     *
     * @return array
     */
    public function get_courses() {
        $post_type = $this->get_course_post_type();
        $pto       = get_post_type_object( $post_type );

        $statuses         = array( 'publish' );
        $read_private_cap = ( $pto && isset( $pto->cap->read_private_posts ) )
            ? $pto->cap->read_private_posts
            : 'read_private_posts';

        if ( current_user_can( $read_private_cap ) ) {
            $statuses = array_merge( $statuses, array( 'draft', 'private', 'pending', 'future' ) );
        }

        $posts = get_posts( array(
            'post_type'        => $post_type,
            'post_status'      => $statuses,
            'posts_per_page'   => 500,
            'orderby'          => 'title',
            'order'            => 'ASC',
            'no_found_rows'    => true,
            'suppress_filters' => true,
        ) );

        $payload = array_map( function ( $post ) {
            return array(
                'id'     => (int) $post->ID,
                'title'  => $post->post_title ? $post->post_title : __( '(No title)', 'eventin-addon-for-tutor-lms' ),
                'status' => $post->post_status,
            );
        }, $posts );

        /**
         * Filter the final course list before it goes to the picker.
         *
         * @since 1.0.0
         *
         * @param array  $payload
         * @param string $post_type
         */
        $payload = apply_filters( 'eventin_tutor_lms_courses_payload', $payload, $post_type );

        return rest_ensure_response( $payload );
    }

    /**
     * GET /diagnostics — small payload that lets the React panel explain
     * exactly why the picker is empty (post type used, total found, edit URL).
     *
     * @return array
     */
    public function get_diagnostics() {
        $post_type = $this->get_course_post_type();
        $count     = wp_count_posts( $post_type );
        $total     = 0;

        if ( $count ) {
            foreach ( array( 'publish', 'draft', 'private', 'pending', 'future' ) as $status ) {
                if ( isset( $count->{$status} ) ) {
                    $total += (int) $count->{$status};
                }
            }
        }

        return rest_ensure_response( array(
            'tutor_active'      => function_exists( 'tutor_utils' ),
            'course_post_type'  => $post_type,
            'total_courses'     => $total,
            'create_course_url' => admin_url( 'post-new.php?post_type=' . $post_type ),
            'manage_url'        => admin_url( 'edit.php?post_type=' . $post_type ),
        ) );
    }

    /**
     * Resolve Tutor LMS' course post type honoring the `tutor_course_post_type`
     * filter. Falls back to the literal 'courses' default.
     *
     * @return string
     */
    protected function get_course_post_type() {
        if ( function_exists( 'tutor' ) ) {
            $cfg = tutor();
            if ( is_object( $cfg ) && ! empty( $cfg->course_post_type ) ) {
                return (string) $cfg->course_post_type;
            }
        }
        return 'courses';
    }
}
