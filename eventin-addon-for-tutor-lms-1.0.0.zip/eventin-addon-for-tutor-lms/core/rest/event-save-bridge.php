<?php
/**
 * Bridges Eventin's native event save with our mapping store.
 *
 * Eventin fires `eventin_event_updated( $event, $request )` and
 * `eventin_event_created( $event, $request )` after every event PUT/POST
 * from the React editor. If the request payload carries a `tutor_lms_mapping`
 * key, we persist it the same way the dedicated REST controller does — so
 * the front-end can either:
 *   (a) submit the mapping inline as part of the event payload, or
 *   (b) call our dedicated /eventin-addon-for-tutor-lms/v1/events/{id}/mapping endpoint.
 *
 * Both paths converge on the same post-meta store.
 *
 * @package Eventin_Tutor/Rest
 */

namespace Eventin_Tutor\Rest;

defined( 'ABSPATH' ) || exit;

use Eventin_Tutor\Contracts\Hookable_Service_Contract;
use WP_Error;

class Event_Save_Bridge implements Hookable_Service_Contract {

    /**
     * Register hooks.
     *
     * @return void
     */
    public function register() {
        add_action( 'eventin_event_updated', array( $this, 'maybe_save_mapping' ), 20, 2 );
        add_action( 'eventin_event_created', array( $this, 'maybe_save_mapping' ), 20, 2 );

        // Also expose the mapping in the event REST response so the React app can
        // hydrate without an extra round-trip on first load.
        add_action( 'rest_api_init', array( $this, 'register_rest_field' ) );
    }

    /**
     * Read `tutor_lms_mapping` off the request and persist it.
     *
     * @param mixed                                   $event   Etn\Core\Event\Event_Model
     * @param \WP_REST_Request|array|null             $request
     * @return void
     */
    public function maybe_save_mapping( $event, $request = null ) {
        if ( ! $event || ! is_object( $event ) || empty( $event->id ) ) {
            return;
        }

        $event_id = (int) $event->id;

        $enabled_payload = $this->extract_enabled_payload( $request );
        if ( null !== $enabled_payload ) {
            eventin_tutor_save_event_enabled( $event_id, (bool) $enabled_payload );
        }

        $payload = $this->extract_mapping_payload( $request );
        if ( null === $payload ) {
            return;
        }

        $clean = array();
        foreach ( (array) $payload as $ticket_slug => $course_ids ) {
            $ticket_slug = sanitize_key( $ticket_slug );
            $course_ids  = array_filter( array_map( 'absint', (array) $course_ids ) );

            if ( '' !== $ticket_slug && ! empty( $course_ids ) ) {
                $clean[ $ticket_slug ] = array_values( $course_ids );
            }
        }

        eventin_tutor_save_ticket_course_map( $event_id, $clean );

        /** This action is documented in core/admin/meta-box.php */
        do_action( 'eventin_tutor_lms_after_save_mapping', (int) $event->id, $clean );
    }

    /**
     * Pull the `tutor_lms_mapping` field out of whatever request shape Eventin
     * passed us. Defensive against array/WP_REST_Request/null.
     *
     * @param mixed $request
     * @return array|null
     */
    protected function extract_mapping_payload( $request ) {
        if ( $request instanceof \WP_REST_Request ) {
            $val = $request->get_param( 'tutor_lms_mapping' );
            return is_array( $val ) ? $val : null;
        }

        if ( is_array( $request ) && isset( $request['tutor_lms_mapping'] ) && is_array( $request['tutor_lms_mapping'] ) ) {
            return $request['tutor_lms_mapping'];
        }

        return null;
    }

    /**
     * Pull the `tutor_lms_enabled` boolean toggle out of the request. Returns
     * null when the field is absent so callers can distinguish "not sent" from
     * "explicitly false."
     *
     * @param mixed $request
     * @return bool|null
     */
    protected function extract_enabled_payload( $request ) {
        if ( $request instanceof \WP_REST_Request ) {
            $val = $request->get_param( 'tutor_lms_enabled' );
            if ( null === $val ) {
                return null;
            }
            return $this->coerce_bool( $val );
        }

        if ( is_array( $request ) && array_key_exists( 'tutor_lms_enabled', $request ) ) {
            return $this->coerce_bool( $request['tutor_lms_enabled'] );
        }

        return null;
    }

    /**
     * Tolerant bool coercion — accepts true/false, 1/0, "1"/"0", "true"/"false".
     *
     * @param mixed $value
     * @return bool
     */
    protected function coerce_bool( $value ) {
        if ( is_bool( $value ) ) {
            return $value;
        }
        if ( is_numeric( $value ) ) {
            return 0 !== (int) $value;
        }
        if ( is_string( $value ) ) {
            $lower = strtolower( $value );
            return in_array( $lower, array( '1', 'true', 'yes', 'on' ), true );
        }
        return (bool) $value;
    }

    /**
     * Expose `tutor_lms_mapping` on the `etn` REST resource so the editor can
     * read it without a separate fetch.
     *
     * @return void
     */
    public function register_rest_field() {
        register_rest_field(
            'etn',
            'tutor_lms_mapping',
            array(
                'get_callback'    => function ( $post ) {
                    return (object) eventin_tutor_get_ticket_course_map( (int) $post['id'] );
                },
                'update_callback' => function ( $value, $post ) {
                    if ( ! is_array( $value ) ) {
                        return;
                    }
                    if ( ! current_user_can( 'edit_post', (int) $post->ID ) ) {
                        return new WP_Error(
                            'rest_forbidden',
                            __( 'You are not allowed to update the Tutor LMS mapping for this event.', 'eventin-addon-for-tutor-lms' ),
                            array( 'status' => rest_authorization_required_code() )
                        );
                    }
                    $clean = array();
                    foreach ( $value as $ticket_slug => $course_ids ) {
                        $ticket_slug = sanitize_key( $ticket_slug );
                        $course_ids  = array_filter( array_map( 'absint', (array) $course_ids ) );
                        if ( '' !== $ticket_slug && ! empty( $course_ids ) ) {
                            $clean[ $ticket_slug ] = array_values( $course_ids );
                        }
                    }
                    eventin_tutor_save_ticket_course_map( (int) $post->ID, $clean );
                },
                'schema'          => array(
                    'description' => __( 'Ticket-slug to Tutor LMS course IDs mapping.', 'eventin-addon-for-tutor-lms' ),
                    'type'        => 'object',
                ),
            )
        );
    }
}
