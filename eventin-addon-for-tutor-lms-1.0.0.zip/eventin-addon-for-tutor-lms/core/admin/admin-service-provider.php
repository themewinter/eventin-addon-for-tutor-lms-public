<?php
/**
 * Admin module service provider. Registers the meta-box & admin UI bindings.
 *
 * @package Eventin_Tutor/Admin
 */

namespace Eventin_Tutor\Admin;

defined( 'ABSPATH' ) || exit;

use Eventin_Tutor\Providers\Base_Service_Provider;

class Admin_Service_Provider extends Base_Service_Provider {

    /**
     * Hookable services for the admin module.
     *
     * @var array
     */
    protected $services = array(
        Meta_Box::class,
    );

    /**
     * Get services with filter for extensibility.
     *
     * @return array
     */
    public function get_services() {
        return apply_filters( 'eventin_tutor_admin_services', $this->services );
    }
}
