<?php
/**
 * Meta-box that lets admins map Eventin ticket variations to Tutor LMS courses.
 *
 * Saved structure (post meta `_eventin_tutor_ticket_course_map`):
 *   [ 'ticket-slug-a' => [ 12, 34 ], 'ticket-slug-b' => [ 56 ] ]
 *
 * Eventin stores tickets in post meta `etn_ticket_variations` on the `etn`
 * post type. Each ticket has at least an `etn_ticket_name` and `etn_ticket_slug`.
 *
 * @package Eventin_Tutor/Admin
 */

namespace Eventin_Tutor\Admin;

defined( 'ABSPATH' ) || exit;

use Eventin_Tutor\Contracts\Hookable_Service_Contract;

class Meta_Box implements Hookable_Service_Contract {

    /**
     * Eventin event post type.
     */
    const EVENT_POST_TYPE = 'etn';

    /**
     * Tutor LMS course post type.
     */
    const COURSE_POST_TYPE = 'courses';

    /**
     * Register hooks.
     *
     * @return void
     */
    public function register() {
        add_action( 'add_meta_boxes', array( $this, 'register_meta_box' ) );
        add_action( 'save_post_' . self::EVENT_POST_TYPE, array( $this, 'save_meta_box' ), 20, 2 );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
    }

    /**
     * Enqueue the meta-box stylesheet on Eventin event editor screens only.
     *
     * @param string $hook Current admin hook.
     * @return void
     */
    public function enqueue_assets( $hook ) {
        if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
            return;
        }

        $screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
        if ( ! $screen || self::EVENT_POST_TYPE !== $screen->post_type ) {
            return;
        }

        $rel  = 'assets/css/admin-meta-box.css';
        $path = EVENTIN_TUTOR_DIR . '/' . $rel;
        $ver  = file_exists( $path ) ? (string) filemtime( $path ) : EVENTIN_TUTOR_VERSION;

        wp_enqueue_style(
            'eventin-addon-for-tutor-lms-meta-box',
            plugins_url( $rel, EVENTIN_TUTOR_FILE ),
            array(),
            $ver
        );
    }

    /**
     * Register the meta-box on the Eventin event editor.
     *
     * @return void
     */
    public function register_meta_box() {
        add_meta_box(
            'eventin-addon-for-tutor-lms-mapping',
            esc_html__( 'Tutor LMS Course Mapping', 'eventin-addon-for-tutor-lms' ),
            array( $this, 'render' ),
            self::EVENT_POST_TYPE,
            'normal',
            'high'
        );
    }

    /**
     * Render the mapping UI.
     *
     * @param \WP_Post $post
     * @return void
     */
    public function render( $post ) {
        wp_nonce_field( 'eventin_tutor_save_mapping', 'eventin_tutor_mapping_nonce' );

        $tickets = eventin_tutor_get_event_tickets( $post->ID );
        $map     = eventin_tutor_get_ticket_course_map( $post->ID );
        $courses = $this->get_courses();

        if ( empty( $tickets ) ) {
            echo '<p>' . esc_html__( 'No ticket variations found yet. Add tickets to this event first, then return here to map them to Tutor LMS courses.', 'eventin-addon-for-tutor-lms' ) . '</p>';
            return;
        }

        echo '<p>' . esc_html__( 'Pick one or more Tutor LMS courses each ticket type should grant access to on successful purchase. Hold Ctrl/Cmd to multi-select.', 'eventin-addon-for-tutor-lms' ) . '</p>';

        echo '<table class="evtn-tutor-mapping-table">';
        echo '<thead><tr>';
        echo '<th>' . esc_html__( 'Ticket', 'eventin-addon-for-tutor-lms' ) . '</th>';
        echo '<th>' . esc_html__( 'Slug', 'eventin-addon-for-tutor-lms' ) . '</th>';
        echo '<th>' . esc_html__( 'Mapped Courses', 'eventin-addon-for-tutor-lms' ) . '</th>';
        echo '</tr></thead><tbody>';

        foreach ( $tickets as $ticket ) {
            $name     = isset( $ticket['etn_ticket_name'] ) ? $ticket['etn_ticket_name'] : '';
            $slug     = isset( $ticket['etn_ticket_slug'] ) ? $ticket['etn_ticket_slug'] : '';
            $selected = isset( $map[ $slug ] ) && is_array( $map[ $slug ] ) ? array_map( 'absint', $map[ $slug ] ) : array();

            echo '<tr>';
            echo '<td><strong>' . esc_html( $name ) . '</strong></td>';
            echo '<td><code>' . esc_html( $slug ) . '</code></td>';
            echo '<td>';
            echo '<select name="eventin_tutor_mapping[' . esc_attr( $slug ) . '][]" multiple size="6">';

            if ( empty( $courses ) ) {
                echo '<option value="" disabled>' . esc_html__( 'No Tutor LMS courses found.', 'eventin-addon-for-tutor-lms' ) . '</option>';
            }

            foreach ( $courses as $course ) {
                echo '<option value="' . esc_attr( $course->ID ) . '"' . selected( in_array( (int) $course->ID, $selected, true ), true, false ) . '>'
                    . esc_html( $course->post_title )
                    . '</option>';
            }

            echo '</select>';
            echo '</td>';
            echo '</tr>';
        }

        echo '</tbody></table>';
    }

    /**
     * Save the mapping.
     *
     * @param int      $post_id
     * @param \WP_Post $post
     * @return void
     */
    public function save_meta_box( $post_id, $post ) {
        if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
            return;
        }
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }
        if ( ! isset( $_POST['eventin_tutor_mapping_nonce'] ) ) {
            return;
        }
        if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['eventin_tutor_mapping_nonce'] ) ), 'eventin_tutor_save_mapping' ) ) {
            return;
        }

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- array values are sanitized below via sanitize_key() and absint()
        $raw = isset( $_POST['eventin_tutor_mapping'] ) ? wp_unslash( $_POST['eventin_tutor_mapping'] ) : array();

        $clean = array();
        if ( is_array( $raw ) ) {
            foreach ( $raw as $ticket_slug => $course_ids ) {
                $ticket_slug = sanitize_key( $ticket_slug );
                $course_ids  = array_filter( array_map( 'absint', (array) $course_ids ) );

                if ( ! empty( $course_ids ) ) {
                    $clean[ $ticket_slug ] = array_values( $course_ids );
                }
            }
        }

        eventin_tutor_save_ticket_course_map( $post_id, $clean );

        /**
         * Fires after the ticket->course mapping is persisted.
         *
         * @since 1.0.0
         *
         * @param int   $post_id Event post ID.
         * @param array $clean   Sanitized mapping array.
         */
        do_action( 'eventin_tutor_lms_after_save_mapping', $post_id, $clean );
    }

    /**
     * Fetch a flat list of Tutor LMS courses for the picker.
     *
     * Public statuses are always included; non-public statuses (draft,
     * private, pending) are only added when the caller can already read
     * private posts of this post type — so editors who don't have visibility
     * into Tutor LMS' unpublished courses don't see them here either.
     *
     * @return \WP_Post[]
     */
    protected function get_courses() {
        $statuses = array( 'publish' );

        $pto              = get_post_type_object( self::COURSE_POST_TYPE );
        $read_private_cap = ( $pto && isset( $pto->cap->read_private_posts ) )
            ? $pto->cap->read_private_posts
            : 'read_private_posts';

        if ( current_user_can( $read_private_cap ) ) {
            $statuses = array_merge( $statuses, array( 'draft', 'private', 'pending' ) );
        }

        $args = array(
            'post_type'      => self::COURSE_POST_TYPE,
            'posts_per_page' => 500,
            'post_status'    => $statuses,
            'orderby'        => 'title',
            'order'          => 'ASC',
            'no_found_rows'  => true,
        );

        /**
         * Filter the WP_Query args used to fetch the course list for the meta-box picker.
         *
         * @since 1.0.0
         *
         * @param array $args
         */
        return get_posts( apply_filters( 'eventin_tutor_lms_course_query_args', $args ) );
    }
}
