<?php
/**
 * User module service provider.
 *
 * @package Eventin_Tutor/User
 */

namespace Eventin_Tutor\User;

defined( 'ABSPATH' ) || exit;

use Eventin_Tutor\Providers\Base_Service_Provider;

class User_Service_Provider extends Base_Service_Provider {

    /**
     * The user module exposes a service that's instantiated lazily by the
     * enrollment module, but we still register a no-op hook layer so that
     * future hooks can attach (e.g. password emails).
     *
     * @var array
     */
    protected $services = array(
        User_Creator::class,
    );

    public function get_services() {
        return apply_filters( 'eventin_tutor_user_services', $this->services );
    }
}
