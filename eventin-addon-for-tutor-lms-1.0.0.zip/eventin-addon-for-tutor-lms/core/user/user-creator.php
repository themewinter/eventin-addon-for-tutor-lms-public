<?php
/**
 * Resolve or create a WordPress user account for an attendee email.
 *
 * @package Eventin_Tutor/User
 */

namespace Eventin_Tutor\User;

defined( 'ABSPATH' ) || exit;

use Eventin_Tutor\Contracts\Hookable_Service_Contract;
use WP_Error;

class User_Creator implements Hookable_Service_Contract {

    /**
     * Hookable_Service_Contract requires register(). Nothing to bind at boot —
     * the enroll handler instantiates User_Creator directly when needed.
     *
     * @return void
     */
    public function register() {}

    /**
     * Resolve the user id for an email, creating a new user if one doesn't exist.
     *
     * @param string $email
     * @param array  $context Extra info — first_name, last_name, phone, source.
     * @return int|WP_Error  User ID on success, WP_Error on failure.
     */
    public function get_or_create( $email, array $context = array() ) {
        $email = sanitize_email( $email );

        if ( ! is_email( $email ) ) {
            return new WP_Error( 'eventin_tutor_invalid_email', __( 'Invalid attendee email; cannot create account.', 'eventin-addon-for-tutor-lms' ) );
        }

        $existing = get_user_by( 'email', $email );
        if ( $existing instanceof \WP_User ) {
            return (int) $existing->ID;
        }

        if ( 'on' !== eventin_tutor_get_option( 'auto_create_users', 'on' ) ) {
            return new WP_Error( 'eventin_tutor_user_creation_disabled', __( 'Auto user creation is disabled in settings.', 'eventin-addon-for-tutor-lms' ) );
        }

        $username = $this->generate_username( $email );
        $password = wp_generate_password( 16, true, false );

        /**
         * Filter the role assigned to newly created attendee users.
         * Default = 'subscriber'. Tutor LMS auto-promotes them to 'student'
         * once they enroll into a course (via _is_tutor_student user meta).
         *
         * @since 1.0.0
         *
         * @param string $role
         * @param string $email
         * @param array  $context
         */
        $role = apply_filters( 'eventin_tutor_lms_new_user_role', 'subscriber', $email, $context );

        $user_data = array(
            'user_login' => $username,
            'user_email' => $email,
            'user_pass'  => $password,
            'role'       => $role,
            'first_name' => isset( $context['first_name'] ) ? sanitize_text_field( $context['first_name'] ) : '',
            'last_name'  => isset( $context['last_name'] )  ? sanitize_text_field( $context['last_name'] )  : '',
        );

        /**
         * Filter the user_data passed to wp_insert_user().
         *
         * @since 1.0.0
         *
         * @param array  $user_data
         * @param string $email
         * @param array  $context
         */
        $user_data = apply_filters( 'eventin_tutor_lms_new_user_args', $user_data, $email, $context );

        $user_id = wp_insert_user( $user_data );

        if ( is_wp_error( $user_id ) ) {
            return $user_id;
        }

        if ( ! empty( $context['phone'] ) ) {
            // WooCommerce interop key — intentionally unprefixed so WC's order
            // history reuses the phone we collected for the Eventin attendee.
            update_user_meta( $user_id, 'billing_phone', sanitize_text_field( $context['phone'] ) );
        }
        update_user_meta( $user_id, '_eventin_tutor_created_user', 1 );

        if ( 'on' === eventin_tutor_get_option( 'send_credentials', 'on' ) ) {
            $this->email_credentials( $user_id, $password, $context );
        }

        /**
         * Fires after a guest attendee account is auto-created.
         *
         * @since 1.0.0
         *
         * @param int    $user_id
         * @param string $email
         * @param array  $context
         */
        do_action( 'eventin_tutor_lms_user_created', $user_id, $email, $context );

        return (int) $user_id;
    }

    /**
     * Build a unique, sanitized username from an email.
     *
     * @param string $email
     * @return string
     */
    protected function generate_username( $email ) {
        $base = sanitize_user( current( explode( '@', $email ) ), true );

        if ( '' === $base ) {
            $base = 'user';
        }

        $username = $base;
        $i        = 1;
        while ( username_exists( $username ) && $i < 1000 ) {
            $username = $base . $i;
            $i++;
        }

        // Pathological fallback — collision count exceeded the bound. Use a
        // random suffix so the insert still has a unique handle.
        if ( username_exists( $username ) ) {
            $username = $base . '-' . wp_generate_password( 6, false, false );
        }

        /**
         * Filter the generated username for a newly created attendee account.
         *
         * @since 1.0.0
         *
         * @param string $username
         * @param string $email
         */
        return (string) apply_filters( 'eventin_tutor_lms_new_username', $username, $email );
    }

    /**
     * Send the new user their credentials. Defers to wp_new_user_notification
     * so existing email plugins (FluentSMTP, etc.) keep working.
     *
     * @param int    $user_id
     * @param string $password
     * @param array  $context
     * @return void
     */
    protected function email_credentials( $user_id, $password, array $context ) {
        /**
         * Allow custom welcome-email handlers to override the default.
         * Return true to indicate the email has been handled and skip core notification.
         *
         * @since 1.0.0
         *
         * @param bool   $handled  Return true to skip core notification.
         * @param int    $user_id
         * @param string $password Plain-text password generated for this user.
         * @param array  $context
         */
        $handled = apply_filters( 'eventin_tutor_lms_send_credentials', false, $user_id, $password, $context );

        if ( $handled ) {
            return;
        }

        // Core WP notification — sends both admin notice + user email containing reset link.
        wp_new_user_notification( $user_id, null, 'both' );
    }
}
