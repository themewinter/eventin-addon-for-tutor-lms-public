<?php
/**
 * Assets module provider — registers the script/style enqueue for the
 * Tutor LMS bridge bundle on Eventin admin pages.
 *
 * @package Eventin_Tutor/Assets
 */

namespace Eventin_Tutor\Assets;

defined( 'ABSPATH' ) || exit;

use Eventin_Tutor\Providers\Base_Service_Provider;

class Assets_Service_Provider extends Base_Service_Provider {

    /** @var array<class-string> */
    protected $services = array(
        Enqueue::class,
    );

    /**
     * @return array
     */
    public function get_services() {
        return apply_filters( 'eventin_tutor_assets_services', $this->services );
    }
}
