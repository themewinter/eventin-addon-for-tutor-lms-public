<?php
/**
 * Enqueue the React bundle (built from src/) on Eventin admin pages.
 *
 * Mirrors Eventin Pro's pattern: a wp-scripts build emits build/index.js plus
 * an `index.asset.php` listing dependency handles + a content-hash version.
 *
 * @package Eventin_Tutor/Assets
 */

namespace Eventin_Tutor\Assets;

defined( 'ABSPATH' ) || exit;

use Eventin_Tutor\Contracts\Hookable_Service_Contract;

class Enqueue implements Hookable_Service_Contract {

    const HANDLE = 'eventin-addon-for-tutor-lms';

    /**
     * Register hooks.
     *
     * @return void
     */
    public function register() {
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
    }

    /**
     * Enqueue the build artifact on Eventin admin screens.
     *
     * @param string $hook Current admin hook.
     * @return void
     */
    public function enqueue( $hook ) {
        if ( ! $this->is_eventin_screen( $hook ) ) {
            return;
        }

        $plugin_dir = EVENTIN_TUTOR_DIR;
        $plugin_url = plugins_url( '', EVENTIN_TUTOR_FILE );

        $script_path = $plugin_dir . '/build/index.js';
        $asset_path  = $plugin_dir . '/build/index.asset.php';
        $style_path  = $plugin_dir . '/build/style-index.css';

        if ( ! file_exists( $script_path ) ) {
            return;
        }

        $asset = file_exists( $asset_path )
            ? require $asset_path
            : array( 'dependencies' => array( 'wp-element', 'wp-hooks', 'wp-api-fetch', 'wp-i18n', 'wp-data' ), 'version' => EVENTIN_TUTOR_VERSION );

        // Ensure the addon loads after Eventin's packages (which expose
        // window.eventin.antd, window.eventin.styled, etc.).
        if ( ! in_array( 'etn-packages', $asset['dependencies'], true ) ) {
            $asset['dependencies'][] = 'etn-packages';
        }

        // Always pin the script to file mtime so admins never see stale builds.
        $version = (string) filemtime( $script_path );

        wp_register_script(
            self::HANDLE,
            $plugin_url . '/build/index.js',
            $asset['dependencies'],
            $version,
            true
        );

        // The bundle calls addFilter() at module-eval time. Eventin's main bundle
        // calls applyFilters() when its router lazy-loads, so as long as our
        // script is in the DOM before the user navigates to /events, the filter
        // is registered in time. Enqueue-as-footer (in_footer = true) is safe
        // because Eventin's chunks load after.
        wp_enqueue_script( self::HANDLE );

        // Pass REST URL + nonce + i18n strings to the bundle.
        wp_localize_script(
            self::HANDLE,
            'eventinTutorLMS',
            array(
                'restUrl'   => esc_url_raw( rest_url( 'eventin-addon-for-tutor-lms/v1' ) ),
                'restNonce' => wp_create_nonce( 'wp_rest' ),
            )
        );

        // Set script translations so __() inside the bundle picks up the .json files.
        if ( function_exists( 'wp_set_script_translations' ) ) {
            wp_set_script_translations( self::HANDLE, 'eventin-addon-for-tutor-lms', $plugin_dir . '/languages' );
        }

        if ( file_exists( $style_path ) ) {
            wp_enqueue_style(
                self::HANDLE,
                $plugin_url . '/build/style-index.css',
                array(),
                (string) filemtime( $style_path )
            );
        }
    }

    /**
     * Detect Eventin admin pages. Eventin namespaces every admin URL under
     * `?page=eventin*`, so a single prefix check is sufficient and survives
     * Eventin renaming or adding pages.
     *
     * @param string $hook Unused; kept for filter parity with admin_enqueue_scripts.
     * @return bool
     */
    protected function is_eventin_screen( $hook ) {
        unset( $hook );

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- $_GET['page'] is a routing parameter, not a form submission
        if ( ! isset( $_GET['page'] ) ) {
            return false;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- $_GET['page'] is a routing parameter, not a form submission
        return 0 === strpos( sanitize_text_field( wp_unslash( $_GET['page'] ) ), 'eventin' );
    }
}
