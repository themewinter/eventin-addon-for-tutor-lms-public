<?php
/**
 * Listens for completed Eventin orders and enrolls the right users into the
 * mapped Tutor LMS courses.
 *
 * Eventin signals we hook into:
 *   - eventin_order_completed( $order )                  primary trigger (native + WC)
 *   - eventin_attendee_payment_completed( $attendee )    fallback per-attendee signal
 *
 * Tutor LMS API used:
 *   - tutor_utils()->do_enroll( $course_id, $order_id, $user_id )
 *
 * @package Eventin_Tutor/Enrollment
 */

namespace Eventin_Tutor\Enrollment;

defined( 'ABSPATH' ) || exit;

use Eventin_Tutor\Contracts\Hookable_Service_Contract;
use Eventin_Tutor\User\User_Creator;

class Enroll_Handler implements Hookable_Service_Contract {

    /**
     * Register hooks.
     *
     * @return void
     */
    public function register() {
        add_action( 'eventin_order_completed', array( $this, 'handle_order_completed' ), 20, 1 );
        add_action( 'eventin_attendee_payment_completed', array( $this, 'handle_attendee_payment_completed' ), 20, 1 );
    }

    /**
     * Top-level handler for a completed Eventin order.
     *
     * @param mixed $order \Etn\Core\Order\OrderModel
     * @return void
     */
    public function handle_order_completed( $order ) {
        if ( ! $order || ! is_object( $order ) ) {
            return;
        }

        $order_id = isset( $order->id ) ? (int) $order->id : 0;
        $event_id = (int) $this->prop( $order, 'event_id' );

        // Per-event integration toggle. When off, no enrollment runs — mirrors
        // the same gate applied in handle_attendee_payment_completed().
        if ( $event_id && ! eventin_tutor_get_event_enabled( $event_id ) ) {
            return;
        }

        // Idempotency guard — never enroll twice for the same order.
        if ( $order_id && get_post_meta( $order_id, '_eventin_tutor_processed', true ) ) {
            return;
        }

        $enroll_mode = eventin_tutor_get_option( 'enroll_mode', 'all_attendees' );
        $map         = eventin_tutor_get_ticket_course_map( $event_id );

        if ( empty( $map ) ) {
            return;
        }

        /**
         * Short-circuit enrollment for an entire order.
         *
         * @since 1.0.0
         *
         * @param bool   $skip  Return true to skip.
         * @param object $order Eventin order model.
         */
        if ( apply_filters( 'eventin_tutor_lms_skip_order', false, $order ) ) {
            return;
        }

        if ( 'purchaser' === $enroll_mode ) {
            $this->enroll_purchaser( $order, $event_id );
        } else {
            $this->enroll_all_attendees( $order, $event_id );
        }

        if ( $order_id ) {
            update_post_meta( $order_id, '_eventin_tutor_processed', current_time( 'mysql' ) );
        }

        /**
         * Fires once per order after every enrollment for that order has been attempted.
         *
         * @since 1.0.0
         *
         * @param object $order
         */
        do_action( 'eventin_tutor_lms_after_order_enrolled', $order );
    }

    /**
     * Per-attendee handler. Eventin fires this from OrderAttendee for each
     * attendee on a completed order, before/alongside `eventin_order_completed`.
     *
     * Per-attendee idempotency lives in {@see enroll_attendee_email()} so the
     * order-level handler can safely re-iterate without duplicating logs.
     *
     * @param mixed $attendee \Etn\Core\Attendee\Attendee_Model
     * @return void
     */
    public function handle_attendee_payment_completed( $attendee ) {
        if ( ! $attendee || ! is_object( $attendee ) ) {
            return;
        }

        $event_id    = (int) $this->prop( $attendee, 'etn_event_id' );
        $email       = sanitize_email( (string) $this->prop( $attendee, 'etn_email' ) );
        $name        = (string) $this->prop( $attendee, 'etn_name' );
        $ticket_slug = (string) $this->prop( $attendee, 'ticket_slug' );
        $order_id    = (int) $this->prop( $attendee, 'eventin_order_id' );

        // Per-event integration toggle. When off, no enrollment runs.
        if ( $event_id && ! eventin_tutor_get_event_enabled( $event_id ) ) {
            return;
        }

        $this->enroll_attendee_email( $email, $name, $event_id, $ticket_slug, $order_id, $attendee );
    }

    /**
     * Enroll only the purchaser. Course set is the union of all courses
     * mapped to every ticket type bought in the order.
     *
     * @param object $order
     * @param int    $event_id
     * @return void
     */
    protected function enroll_purchaser( $order, $event_id ) {
        $email      = sanitize_email( (string) $this->prop( $order, 'customer_email' ) );
        $first_name = (string) $this->prop( $order, 'customer_fname' );
        $last_name  = (string) $this->prop( $order, 'customer_lname' );
        $phone      = (string) $this->prop( $order, 'customer_phone' );
        $order_id   = isset( $order->id ) ? (int) $order->id : 0;

        if ( ! $email ) {
            return;
        }

        $course_ids = $this->collect_course_ids_for_order( $order, $event_id );
        if ( empty( $course_ids ) ) {
            return;
        }

        $context = array(
            'first_name' => $first_name,
            'last_name'  => $last_name,
            'phone'      => $phone,
            'source'     => 'eventin_purchaser',
            'event_id'   => $event_id,
            'order_id'   => $order_id,
        );

        $user_id = $this->resolve_user_id( $email, $context );
        if ( ! $user_id ) {
            return;
        }

        foreach ( $course_ids as $course_id ) {
            $this->do_enroll( (int) $course_id, $user_id, $order_id, $email, $context );
        }
    }

    /**
     * Enroll every attendee on the order — each into the course set mapped
     * to *their* ticket slug.
     *
     * @param object $order
     * @param int    $event_id
     * @return void
     */
    protected function enroll_all_attendees( $order, $event_id ) {
        $attendees = method_exists( $order, 'get_attendees' ) ? $order->get_attendees() : array();
        $order_id  = isset( $order->id ) ? (int) $order->id : 0;

        if ( empty( $attendees ) ) {
            // Fall back to purchaser if no attendees were created.
            $this->enroll_purchaser( $order, $event_id );
            return;
        }

        foreach ( $attendees as $attendee ) {
            $email       = sanitize_email( (string) $this->prop( $attendee, 'etn_email' ) );
            $name        = (string) $this->prop( $attendee, 'etn_name' );
            $ticket_slug = (string) $this->prop( $attendee, 'ticket_slug' );

            $this->enroll_attendee_email( $email, $name, $event_id, $ticket_slug, $order_id, $attendee );
        }
    }

    /**
     * Workhorse for one attendee row.
     *
     * @param string $email
     * @param string $name
     * @param int    $event_id
     * @param string $ticket_slug
     * @param int    $order_id
     * @param object $attendee
     * @return void
     */
    protected function enroll_attendee_email( $email, $name, $event_id, $ticket_slug, $order_id, $attendee = null ) {
        if ( ! $email || ! is_email( $email ) ) {
            return;
        }

        // Per-attendee idempotency. Both eventin_attendee_payment_completed and
        // eventin_order_completed fire for the same attendee in a typical flow;
        // this guard ensures we only enroll/log once per attendee.
        $attendee_id = is_object( $attendee ) && isset( $attendee->id ) ? (int) $attendee->id
            : ( is_array( $attendee ) && isset( $attendee['id'] ) ? (int) $attendee['id'] : 0 );

        if ( $attendee_id && get_post_meta( $attendee_id, '_eventin_tutor_processed', true ) ) {
            return;
        }

        $course_ids = eventin_tutor_courses_for_ticket( $event_id, $ticket_slug );
        if ( empty( $course_ids ) ) {
            return;
        }

        list( $first, $last ) = $this->split_name( $name );

        $context = array(
            'first_name'  => $first,
            'last_name'   => $last,
            'source'      => 'eventin_attendee',
            'event_id'    => $event_id,
            'order_id'    => $order_id,
            'ticket_slug' => $ticket_slug,
            'attendee'    => $attendee,
        );

        $user_id = $this->resolve_user_id( $email, $context );
        if ( ! $user_id ) {
            return;
        }

        foreach ( $course_ids as $course_id ) {
            $this->do_enroll( (int) $course_id, $user_id, $order_id, $email, $context );
        }

        if ( $attendee_id ) {
            update_post_meta( $attendee_id, '_eventin_tutor_processed', current_time( 'mysql' ) );
        }
    }

    /**
     * Resolve a user id for an email — existing user wins, otherwise create one
     * via the User_Creator service.
     *
     * @param string $email
     * @param array  $context
     * @return int   0 on failure.
     */
    protected function resolve_user_id( $email, array $context ) {
        $existing = get_user_by( 'email', $email );
        if ( $existing instanceof \WP_User ) {
            return (int) $existing->ID;
        }

        $creator = new User_Creator();
        $result  = $creator->get_or_create( $email, $context );

        if ( is_wp_error( $result ) ) {
            return 0;
        }

        return (int) $result;
    }

    /**
     * Aggregate every course id mapped to any ticket bought in this order.
     *
     * @param object $order
     * @param int    $event_id
     * @return int[]
     */
    protected function collect_course_ids_for_order( $order, $event_id ) {
        $course_ids = array();

        $tickets = $this->prop( $order, 'tickets' );
        if ( ! is_array( $tickets ) ) {
            return $course_ids;
        }

        foreach ( $tickets as $ticket ) {
            $slug = isset( $ticket['ticket_slug'] ) ? $ticket['ticket_slug'] : '';
            $mapped = eventin_tutor_courses_for_ticket( $event_id, $slug );

            if ( $mapped ) {
                $course_ids = array_merge( $course_ids, $mapped );
            }
        }

        return array_unique( array_map( 'absint', $course_ids ) );
    }

    /**
     * Wrap tutor_utils()->do_enroll() with our own filter / action contract.
     *
     * @param int    $course_id
     * @param int    $user_id
     * @param int    $order_id
     * @param string $email
     * @param array  $context
     * @return int   Enrollment ID, 0 on failure.
     */
    protected function do_enroll( $course_id, $user_id, $order_id, $email, array $context ) {
        if ( ! function_exists( 'tutor_utils' ) ) {
            return 0;
        }

        if ( ! $course_id || ! $user_id ) {
            return 0;
        }

        // Skip if the course was deleted between mapping and enrollment.
        if ( ! get_post( $course_id ) ) {
            return 0;
        }

        /**
         * Last chance to short-circuit a single enrollment.
         *
         * @since 1.0.0
         *
         * @param bool  $skip
         * @param int   $course_id
         * @param int   $user_id
         * @param array $context
         */
        if ( apply_filters( 'eventin_tutor_lms_skip_enrollment', false, $course_id, $user_id, $context ) ) {
            return 0;
        }

        /**
         * Fires immediately before a single course enrollment is created.
         *
         * @since 1.0.0
         *
         * @param int   $course_id
         * @param int   $user_id
         * @param array $context
         */
        do_action( 'eventin_tutor_lms_before_enroll', $course_id, $user_id, $context );

        $enrolled_id = tutor_utils()->do_enroll( $course_id, $order_id, $user_id );

        // Track enrollments produced by this addon so we can selectively reverse them later.
        if ( $enrolled_id ) {
            $tracked = get_post_meta( $enrolled_id, '_eventin_tutor_origin', true );
            if ( ! $tracked ) {
                update_post_meta( $enrolled_id, '_eventin_tutor_origin', array(
                    'order_id'    => $order_id,
                    'event_id'    => isset( $context['event_id'] ) ? (int) $context['event_id'] : 0,
                    'ticket_slug' => isset( $context['ticket_slug'] ) ? (string) $context['ticket_slug'] : '',
                    'email'       => $email,
                ) );
            }
        }

        /**
         * Fires after a single course enrollment has been created.
         *
         * @since 1.0.0
         *
         * @param int   $course_id
         * @param int   $user_id
         * @param int   $enrolled_id Tutor LMS enrollment post ID.
         * @param array $context
         */
        do_action( 'eventin_tutor_lms_after_enroll', $course_id, $user_id, $enrolled_id, $context );

        return (int) $enrolled_id;
    }

    /**
     * Split "First Last" into a [first, last] pair. Defensive — Eventin sometimes
     * stores a single name field, sometimes two.
     *
     * @param string $full
     * @return array{0:string,1:string}
     */
    protected function split_name( $full ) {
        $full  = trim( (string) $full );
        $parts = preg_split( '/\s+/', $full, 2 );

        $first = $parts[0] ?? '';
        $last  = $parts[1] ?? '';

        return array( $first, $last );
    }

    /**
     * Safely read a property off an Eventin Post_Model subclass OR a plain
     * array of attendee/order data.
     *
     * Two quirks this works around:
     *  1. Eventin's Post_Model uses __get() but does NOT implement __isset(),
     *     so isset($model->key) is always false even when data is present.
     *  2. OrderModel::get_attendees() returns plain associative arrays
     *     (the result of $attendee->get_data()), NOT Attendee_Model
     *     objects, so we need array fallback.
     *
     * @param mixed  $obj  Object or array.
     * @param string $key
     * @return mixed
     */
    protected function prop( $obj, $key ) {
        if ( is_array( $obj ) ) {
            return isset( $obj[ $key ] ) ? $obj[ $key ] : null;
        }
        if ( is_object( $obj ) ) {
            try {
                return $obj->{$key};
            } catch ( \Throwable $e ) {
                return null;
            }
        }
        return null;
    }
}
