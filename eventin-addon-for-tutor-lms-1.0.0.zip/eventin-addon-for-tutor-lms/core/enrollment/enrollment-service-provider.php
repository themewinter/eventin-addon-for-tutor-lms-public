<?php
/**
 * Enrollment module service provider.
 *
 * @package Eventin_Tutor/Enrollment
 */

namespace Eventin_Tutor\Enrollment;

defined( 'ABSPATH' ) || exit;

use Eventin_Tutor\Providers\Base_Service_Provider;

class Enrollment_Service_Provider extends Base_Service_Provider {

    /**
     * @var array
     */
    protected $services = array(
        Enroll_Handler::class,
        Unenroll_Handler::class,
    );

    public function get_services() {
        return apply_filters( 'eventin_tutor_enrollment_services', $this->services );
    }
}
