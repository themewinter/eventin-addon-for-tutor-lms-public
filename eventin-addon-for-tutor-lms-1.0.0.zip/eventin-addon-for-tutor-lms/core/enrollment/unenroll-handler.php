<?php
/**
 * Reverses Tutor LMS enrollments produced by this addon when an Eventin order
 * is refunded, cancelled, or deleted.
 *
 * Eventin signals consumed:
 *   - eventin_order_refund( $order )            refund / cancel / failed
 *   - eventin_attendee_deleted( $attendee_id )  attendee row removed
 *
 * @package Eventin_Tutor/Enrollment
 */

namespace Eventin_Tutor\Enrollment;

defined( 'ABSPATH' ) || exit;

use Eventin_Tutor\Contracts\Hookable_Service_Contract;

class Unenroll_Handler implements Hookable_Service_Contract {

    /**
     * Register hooks.
     *
     * @return void
     */
    public function register() {
        add_action( 'eventin_order_refund', array( $this, 'handle_order_refund' ), 20, 1 );
        add_action( 'eventin_order_status_failed', array( $this, 'handle_order_refund' ), 20, 1 );
        add_action( 'eventin_order_failed', array( $this, 'handle_order_refund' ), 20, 1 );
        add_action( 'eventin_attendee_deleted', array( $this, 'handle_attendee_deleted' ), 20, 1 );
    }

    /**
     * Cancel every enrollment that originated from the given order.
     *
     * @param mixed $order \Etn\Core\Order\OrderModel
     * @return void
     */
    public function handle_order_refund( $order ) {
        if ( 'on' !== eventin_tutor_get_option( 'unenroll_on_refund', 'on' ) ) {
            return;
        }

        if ( ! $order || ! is_object( $order ) ) {
            return;
        }

        $order_id = isset( $order->id ) ? (int) $order->id : 0;
        if ( ! $order_id ) {
            return;
        }

        $event_id = (int) ( $order->event_id ?? 0 );
        if ( $event_id && ! eventin_tutor_get_event_enabled( $event_id ) ) {
            return;
        }

        $enrollments = $this->find_enrollments_by_order( $order_id );
        if ( empty( $enrollments ) ) {
            return;
        }

        foreach ( $enrollments as $enrolled ) {
            $this->cancel( $enrolled );
        }

        // Clear processed flag — if the order is later re-completed (e.g. partial
        // refund reversed), the enroll handler should be free to re-run.
        delete_post_meta( $order_id, '_eventin_tutor_processed' );

        /**
         * Fires after every enrollment for an order has been cancelled.
         *
         * @since 1.0.0
         *
         * @param object $order
         */
        do_action( 'eventin_tutor_lms_after_order_unenrolled', $order );
    }

    /**
     * Cancel any enrollment tied to a deleted attendee.
     *
     * @param int $attendee_id
     * @return void
     */
    public function handle_attendee_deleted( $attendee_id ) {
        $attendee_id = (int) $attendee_id;

        if ( ! $attendee_id || ! function_exists( 'tutor_utils' ) ) {
            return;
        }

        $email      = sanitize_email( (string) get_post_meta( $attendee_id, 'etn_email', true ) );
        $event_id   = (int) get_post_meta( $attendee_id, 'etn_event_id', true );
        $ticket_slug = sanitize_key( (string) get_post_meta( $attendee_id, 'ticket_slug', true ) );

        if ( ! $email || ! $event_id ) {
            return;
        }

        $user = get_user_by( 'email', $email );
        if ( ! $user ) {
            return;
        }

        $course_ids = eventin_tutor_courses_for_ticket( $event_id, $ticket_slug );
        foreach ( $course_ids as $course_id ) {
            tutor_utils()->cancel_course_enrol( (int) $course_id, (int) $user->ID, 'cancel' );

            /**
             * Fires after a single attendee has been unenrolled from a mapped course.
             *
             * @since 1.0.0
             *
             * @param int $course_id
             * @param int $user_id
             * @param int $attendee_id Eventin attendee post ID.
             */
            do_action( 'eventin_tutor_lms_attendee_unenrolled', $course_id, $user->ID, $attendee_id );
        }
    }

    /**
     * Find every `tutor_enrolled` post that we marked with this order id.
     *
     * @param int $order_id
     * @return \WP_Post[]
     */
    protected function find_enrollments_by_order( $order_id ) {
        global $wpdb;

        $order_id = (int) $order_id;
        if ( ! $order_id ) {
            return array();
        }

        // Direct query — `get_posts()` silently filters out `tutor_enrolled` rows
        // in some configurations (post type visibility / pre_get_posts filters),
        // so meta lookup misses live enrollments. The meta key is owned by Tutor LMS
        // (see Utils::do_enroll), so a direct join is reliable.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT p.ID, p.post_parent, p.post_author, p.post_status
             FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} m ON m.post_id = p.ID
             WHERE p.post_type = %s
               AND p.post_status IN ( 'completed', 'pending', 'cancel', 'cancelled' )
               AND m.meta_key = %s
               AND m.meta_value = %s",
            'tutor_enrolled',
            '_tutor_enrolled_by_order_id',
            (string) $order_id
        ) );

        if ( ! is_array( $rows ) ) {
            return array();
        }

        // Adapt rows to the WP_Post-ish shape `cancel()` consumes.
        $posts = array();
        foreach ( $rows as $row ) {
            $post = new \stdClass();
            $post->ID          = (int) $row->ID;
            $post->post_parent = (int) $row->post_parent;
            $post->post_author = (int) $row->post_author;
            $post->post_status = (string) $row->post_status;
            $posts[] = $post;
        }

        return $posts;
    }

    /**
     * Cancel a single enrollment via Tutor LMS' utility.
     *
     * @param object $enrolled  Either WP_Post or stdClass with post_parent/post_author/ID.
     * @return void
     */
    protected function cancel( $enrolled ) {
        if ( ! function_exists( 'tutor_utils' ) ) {
            return;
        }

        $course_id = (int) $enrolled->post_parent;
        $user_id   = (int) $enrolled->post_author;

        if ( ! $course_id || ! $user_id ) {
            return;
        }

        /**
         * Fires immediately before a single enrollment is cancelled.
         *
         * @since 1.0.0
         *
         * @param int      $course_id
         * @param int      $user_id
         * @param \WP_Post $enrolled Tutor enrollment post.
         */
        do_action( 'eventin_tutor_lms_before_unenroll', $course_id, $user_id, $enrolled );

        tutor_utils()->cancel_course_enrol( $course_id, $user_id, 'cancel' );

        /**
         * Fires after a single enrollment has been cancelled.
         *
         * @since 1.0.0
         *
         * @param int      $course_id
         * @param int      $user_id
         * @param \WP_Post $enrolled Tutor enrollment post.
         */
        do_action( 'eventin_tutor_lms_after_unenroll', $course_id, $user_id, $enrolled );
    }
}
