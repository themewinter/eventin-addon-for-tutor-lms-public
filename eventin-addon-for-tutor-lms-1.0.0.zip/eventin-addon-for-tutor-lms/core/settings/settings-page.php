<?php
/**
 * WP Settings API option registration for the addon's global options.
 *
 * The visual settings UI lives in the Eventin extension page; this class
 * only registers the option blob + sanitize callback so any options.php
 * POST keeps validating through the same sanitizer.
 *
 * @package Eventin_Tutor/Settings
 */

namespace Eventin_Tutor\Settings;

defined( 'ABSPATH' ) || exit;

use Eventin_Tutor\Contracts\Hookable_Service_Contract;

class Settings_Page implements Hookable_Service_Contract {

    const OPTION_KEY = 'eventin_tutor_lms_options';
    const PAGE_SLUG  = 'eventin-addon-for-tutor-lms';

    /**
     * Register hooks.
     *
     * @return void
     */
    public function register() {
        add_action( 'admin_init', array( $this, 'register_settings' ) );
    }

    /**
     * Register the option blob.
     *
     * @return void
     */
    public function register_settings() {
        register_setting(
            'eventin_tutor_lms_settings',
            self::OPTION_KEY,
            array( $this, 'sanitize' )
        );
    }

    /**
     * Sanitize submitted options.
     *
     * @param array $input
     * @return array
     */
    public function sanitize( $input ) {
        $clean = array();

        $mode                       = isset( $input['enroll_mode'] ) ? sanitize_key( $input['enroll_mode'] ) : 'all_attendees';
        $clean['enroll_mode']       = in_array( $mode, array( 'purchaser', 'all_attendees' ), true ) ? $mode : 'all_attendees';
        $clean['auto_create_users'] = ! empty( $input['auto_create_users'] ) ? 'on' : 'off';
        $clean['send_credentials']  = ! empty( $input['send_credentials'] ) ? 'on' : 'off';
        $clean['unenroll_on_refund'] = ! empty( $input['unenroll_on_refund'] ) ? 'on' : 'off';

        /**
         * Filter the sanitized settings before they are persisted.
         *
         * @since 1.0.0
         *
         * @param array $clean Sanitized settings.
         * @param array $input Raw user input.
         */
        return apply_filters( 'eventin_tutor_lms_sanitize_settings', $clean, $input );
    }
}
