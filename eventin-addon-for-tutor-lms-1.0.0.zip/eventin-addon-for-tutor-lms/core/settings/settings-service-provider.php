<?php
/**
 * Settings module service provider.
 *
 * @package Eventin_Tutor/Settings
 */

namespace Eventin_Tutor\Settings;

defined( 'ABSPATH' ) || exit;

use Eventin_Tutor\Providers\Base_Service_Provider;

class Settings_Service_Provider extends Base_Service_Provider {

    /**
     * Hookable services.
     *
     * @var array
     */
    protected $services = array(
        Settings_Page::class,
    );

    /**
     * @return array
     */
    public function get_services() {
        return apply_filters( 'eventin_tutor_settings_services', $this->services );
    }
}
