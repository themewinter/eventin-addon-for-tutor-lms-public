<?php
/**
 * Uninstall handler — removes plugin options and metadata.
 *
 * Fires only when the user deletes the plugin from wp-admin (not on
 * deactivation). Multisite-aware: walks every site on the network.
 *
 * @package Eventin_Tutor
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

/**
 * Delete plugin data for a single site.
 *
 * @return void
 */
function eventin_tutor_uninstall_site() {
    global $wpdb;

    delete_option( 'eventin_tutor_lms_options' );

    // Post meta written by the plugin.
    $post_meta_keys = array(
        '_eventin_tutor_ticket_course_map',
        '_eventin_tutor_processed',
        '_eventin_tutor_origin',
    );

    foreach ( $post_meta_keys as $meta_key ) {
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->delete( $wpdb->postmeta, array( 'meta_key' => $meta_key ) );
    }

    // User meta written by the plugin's User_Creator.
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $wpdb->delete( $wpdb->usermeta, array( 'meta_key' => '_eventin_tutor_created_user' ) );
}

if ( is_multisite() ) {
    $site_ids = get_sites( array( 'fields' => 'ids', 'number' => 0 ) );
    foreach ( $site_ids as $site_id ) {
        switch_to_blog( (int) $site_id );
        eventin_tutor_uninstall_site();
        restore_current_blog();
    }
} else {
    eventin_tutor_uninstall_site();
}
