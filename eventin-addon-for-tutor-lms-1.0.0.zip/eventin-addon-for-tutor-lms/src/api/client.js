/**
 * Thin wrapper around wp.apiFetch.
 *
 * Uses leading-slash paths so the WP-default rootURL middleware
 * (already registered by wp-api-fetch with wpApiSettings.root)
 * routes them correctly. We deliberately don't register our own
 * createRootURLMiddleware — that would hijack Eventin's REST calls.
 */

import apiFetch from '@wordpress/api-fetch';

const NS = '/eventin-addon-for-tutor-lms/v1';

export function getMapping( eventId ) {
	return apiFetch( { path: `${ NS }/events/${ eventId }/mapping` } );
}

export function saveMapping( eventId, mapping ) {
	return apiFetch( {
		path: `${ NS }/events/${ eventId }/mapping`,
		method: 'POST',
		data: { mapping },
	} );
}

export function getCourses() {
	return apiFetch( { path: `${ NS }/courses` } );
}

export function getDiagnostics() {
	return apiFetch( { path: `${ NS }/diagnostics` } );
}
