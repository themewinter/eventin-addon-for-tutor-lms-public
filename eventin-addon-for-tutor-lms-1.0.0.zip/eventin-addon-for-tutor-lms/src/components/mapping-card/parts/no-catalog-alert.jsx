import { __ } from '@wordpress/i18n';
import { Alert } from 'antd';

import { BannerWrapper } from '../style';

export default function NoCatalogAlert( { createCourseUrl } ) {
	return (
		<BannerWrapper>
			<Alert
				message={
					<strong>
						{ __(
							"You don't have any Tutor LMS courses yet.",
							'eventin-addon-for-tutor-lms'
						) }
					</strong>
				}
				description={ __(
					'Create at least one course, then return here to map your tickets to it.',
					'eventin-addon-for-tutor-lms'
				) }
				type="info"
				showIcon
				action={
					<a
						href={ createCourseUrl }
						target="_blank"
						rel="noopener noreferrer"
					>
						{ __(
							'＋ Create a course in Tutor LMS',
							'eventin-addon-for-tutor-lms'
						) }
					</a>
				}
			/>
		</BannerWrapper>
	);
}
