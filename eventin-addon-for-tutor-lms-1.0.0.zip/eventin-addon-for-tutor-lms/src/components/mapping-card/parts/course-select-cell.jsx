import { __ } from '@wordpress/i18n';
import { Select } from 'antd';

import { CourseSelect } from '../style';

const { Option } = Select;

export default function CourseSelectCell( { courses, value, onChange } ) {
	if ( ! courses.length ) {
		return (
			<em style={ { color: '#9ca3af' } }>
				{ __(
					'No Tutor LMS courses found.',
					'eventin-addon-for-tutor-lms'
				) }
			</em>
		);
	}

	return (
		<CourseSelect
			value={ value ? String( value ) : undefined }
			placeholder={ __(
				'— Select a course —',
				'eventin-addon-for-tutor-lms'
			) }
			allowClear
			onChange={ ( next ) => onChange( next || '' ) }
		>
			{ courses.map( ( c ) => (
				<Option key={ c.id } value={ String( c.id ) }>
					{ c.title }
				</Option>
			) ) }
		</CourseSelect>
	);
}
