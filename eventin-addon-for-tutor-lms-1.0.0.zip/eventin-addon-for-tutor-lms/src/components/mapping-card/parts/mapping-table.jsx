import { __ } from '@wordpress/i18n';
import { Table } from 'antd';

import { TicketNameCell, SlugCell } from '../style';
import CourseSelectCell from './course-select-cell';

export default function MappingTable( {
	tickets,
	courses,
	mapping,
	onChangeTicket,
} ) {
	const columns = [
		{
			title: __( 'Ticket', 'eventin-addon-for-tutor-lms' ),
			dataIndex: 'name',
			key: 'name',
			width: '35%',
			render: ( name ) => <TicketNameCell>{ name }</TicketNameCell>,
		},
		{
			title: __( 'Slug', 'eventin-addon-for-tutor-lms' ),
			dataIndex: 'slug',
			key: 'slug',
			width: '25%',
			render: ( slug ) => <SlugCell>{ slug }</SlugCell>,
		},
		{
			title: __( 'Mapped Course', 'eventin-addon-for-tutor-lms' ),
			dataKey: 'course',
			width: '40%',
			render: ( _, record ) => (
				<CourseSelectCell
					courses={ courses }
					value={ mapping[ record.slug ]?.[ 0 ] || '' }
					onChange={ ( value ) =>
						onChangeTicket( record.slug, value )
					}
				/>
			),
		},
	];

	const dataSource = tickets.map( ( t ) => ( {
		...t,
		key: t.slug || t.name,
	} ) );

	return (
		<Table
			columns={ columns }
			dataSource={ dataSource }
			pagination={ false }
			size="middle"
			rowKey="key"
		/>
	);
}
