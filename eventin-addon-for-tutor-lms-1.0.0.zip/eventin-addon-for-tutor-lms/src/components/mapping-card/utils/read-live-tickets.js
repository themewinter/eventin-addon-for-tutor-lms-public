/**
 * Read ticket variations from Eventin's globally-exposed antd form
 * (most reliable; populated on initial event load), falling back to
 * wp.data.select('eventin/events').getEventState().ticketVariations.
 */
export function readLiveTickets() {
	try {
		const form = window.eventin?.EventForm;
		if ( form && typeof form.getFieldValue === 'function' ) {
			const v = form.getFieldValue( 'ticket_variations' );
			if ( Array.isArray( v ) && v.length ) {
				return v
					.map( ( t ) => ( {
						name: t.etn_ticket_name || t.ticket_name || '',
						slug: t.etn_ticket_slug || t.ticket_slug || '',
					} ) )
					.filter( ( t ) => t.slug );
			}
		}
	} catch ( e ) {}

	try {
		const state = window.wp?.data
			?.select?.( 'eventin/events' )
			?.getEventState?.();
		if ( state && Array.isArray( state.ticketVariations ) ) {
			return state.ticketVariations
				.map( ( v ) => ( {
					name: v.etn_ticket_name || v.ticket_name || '',
					slug: v.etn_ticket_slug || v.ticket_slug || '',
				} ) )
				.filter( ( t ) => t.slug );
		}
	} catch ( e ) {}

	return [];
}
