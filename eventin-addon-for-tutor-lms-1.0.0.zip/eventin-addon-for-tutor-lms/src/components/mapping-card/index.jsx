/**
 * The Tutor LMS integration section, rendered inline inside Eventin's
 * Third-Party Integrations card on the Advanced tab.
 *
 * UX mirrors the FluentCRM row: a collapsible Ant Collapse with a
 * header (icon + title + description) and a switch in `extra` to
 * expand/collapse the mapping body.
 *
 * Composition only — data fetching, polling, styles, and table rendering
 * live in their own modules under this directory. No Save button — Eventin's
 * global Update button persists everything via the apiFetch save middleware
 * + window.eventin.EventForm bridge.
 */

import { useCallback } from '@wordpress/element';
import { __ } from '@wordpress/i18n';

import { Alert, Spin, Empty, Switch, Collapse } from 'antd';
import {
	WarningOutlined,
	CheckOutlined,
	CloseOutlined,
} from '@ant-design/icons';

const TutorLmsIcon = () => (
	<svg
		width="20"
		height="20"
		viewBox="0 0 24 24"
		fill="none"
		xmlns="http://www.w3.org/2000/svg"
		aria-hidden="true"
	>
		<path
			d="M12 3 1 9l11 6 9-4.91V17h2V9L12 3zm-7 9.18v4L12 20l7-3.82v-4L12 16l-7-3.82z"
			fill="currentColor"
		/>
	</svg>
);

import {
	setPendingMapping,
	setPendingEnabled,
} from '../../filters/save-middleware';
import { useMappingData } from './hooks/use-mapping-data';
import { useLiveTicketsPoll } from './hooks/use-live-tickets-poll';
import NoCatalogAlert from './parts/no-catalog-alert';
import MappingTable from './parts/mapping-table';
import {
	CollapseWrapper,
	CollapseHeader,
	HeaderIcon,
	HeaderText,
	HeaderTitle,
	HeaderDescription,
	HelpText,
	StyledSwitch,
} from './style';

const { Panel } = Collapse;
const PANEL_KEY = '1';

export default function MappingCard( { eventId } ) {
	const {
		tickets,
		setTickets,
		mapping,
		setMapping,
		enabled,
		setEnabled,
		courses,
		diagnostics,
		loading,
		error,
	} = useMappingData( eventId );

	useLiveTicketsPoll( setTickets );

	const onChangeTicket = useCallback(
		( slug, value ) => {
			const id = parseInt( value, 10 );
			const next = { ...mapping };

			if ( id ) {
				next[ slug ] = [ id ];
			} else {
				delete next[ slug ];
			}

			setPendingMapping( eventId, next );
			setMapping( next );
		},
		[ mapping, eventId, setMapping ]
	);

	const noCatalog =
		diagnostics && diagnostics.tutor_active && ! diagnostics.total_courses;

	const handleSwitchChange = ( checked ) => {
		setEnabled( checked );
		setPendingEnabled( eventId, checked );
	};

	const handleCollapseChange = ( activeKeys ) => {
		const next = Boolean( activeKeys.length );
		setEnabled( next );
		setPendingEnabled( eventId, next );
	};

	return (
		<CollapseWrapper>
			<Collapse
				activeKey={ enabled ? [ PANEL_KEY ] : [] }
				onChange={ handleCollapseChange }
				collapsible="header"
				className="eventin-collapse-wrapper"
			>
				<Panel
					key={ PANEL_KEY }
					showArrow={ false }
					header={
						<CollapseHeader>
							<HeaderIcon>
								<TutorLmsIcon />
							</HeaderIcon>
							<HeaderText>
								<HeaderTitle>
									{ __(
										'Integrate Tutor LMS',
										'eventin-addon-for-tutor-lms'
									) }
								</HeaderTitle>
								<HeaderDescription>
									{ __(
										'Map ticket types to Tutor LMS courses unlocked on purchase.',
										'eventin-addon-for-tutor-lms'
									) }
								</HeaderDescription>
							</HeaderText>
						</CollapseHeader>
					}
					extra={
						<StyledSwitch
							className="etn-custom-switch"
							onClick={ ( e ) => e.stopPropagation() }
						>
							<Switch
								checked={ enabled }
								onChange={ handleSwitchChange }
								checkedChildren={ <CheckOutlined /> }
								unCheckedChildren={ <CloseOutlined /> }
							/>
						</StyledSwitch>
					}
				>
					<HelpText>
						{ __(
							'Pick the Tutor LMS course(s) each ticket type unlocks on successful purchase. Saved when you click Update at the top of the page.',
							'eventin-addon-for-tutor-lms'
						) }
					</HelpText>

					{ noCatalog && (
						<NoCatalogAlert
							createCourseUrl={ diagnostics.create_course_url }
						/>
					) }

					{ error && (
						<Alert
							message={ error }
							type="error"
							showIcon
							icon={ <WarningOutlined /> }
							style={ { marginBottom: 16 } }
						/>
					) }

					{ loading ? (
						<div
							style={ {
								textAlign: 'center',
								padding: '24px 0',
							} }
						>
							<Spin />
						</div>
					) : (
						<>
							{ ! tickets.length && (
								<Empty
									image={ Empty.PRESENTED_IMAGE_SIMPLE }
									description={
										<span>
											{ __(
												'Add a ticket variation in the Tickets tab. It will appear here automatically — no save needed.',
												'eventin-addon-for-tutor-lms'
											) }
										</span>
									}
									style={ { margin: '24px 0' } }
								/>
							) }

							{ tickets.length > 0 && (
								<MappingTable
									tickets={ tickets }
									courses={ courses }
									mapping={ mapping }
									onChangeTicket={ onChangeTicket }
								/>
							) }
						</>
					) }
				</Panel>
			</Collapse>
		</CollapseWrapper>
	);
}
