import styled from '@emotion/styled';
import { Typography, Select } from 'antd';

const { Paragraph } = Typography;

export const CollapseWrapper = styled.div`
	margin-top: 16px;

	.ant-collapse {
		border-color: #e3e3e3;
		background: #fff;
	}
	.ant-collapse-item {
		border-color: #e3e3e3;
	}
	.ant-collapse-header {
		align-items: center !important;
		padding: 16px 20px !important;
	}
	.ant-collapse-content {
		background-color: #fff;
		border-color: #e3e3e3;
	}
	.ant-collapse-content-box {
		padding: 20px !important;
	}
`;

export const CollapseHeader = styled.div`
	display: flex;
	align-items: center;
	gap: 12px;
`;

export const HeaderIcon = styled.div`
	width: 36px;
	height: 36px;
	display: flex;
	align-items: center;
	justify-content: center;
	border-radius: 8px;
	background: #f3eaff;
	color: #6c1bea;
	font-size: 18px;
	flex-shrink: 0;
`;

export const HeaderText = styled.div`
	display: flex;
	flex-direction: column;
	gap: 2px;
`;

export const HeaderTitle = styled.h4`
	margin: 0;
	font-size: 14px;
	font-weight: 500;
	color: #212327;
	line-height: 20px;
`;

export const HeaderDescription = styled.span`
	font-size: 13px;
	color: #5c728d;
	line-height: 18px;
	font-weight: normal;
`;

export const HelpText = styled( Paragraph )`
	color: #6b7280;
	margin-bottom: 16px;
`;

export const StyledSwitch = styled.div`
	.ant-switch {
		min-width: 36px;
		height: 24px;
		background-color: #d1d5db;
	}
	.ant-switch.ant-switch-checked {
		background-color: #5700d1;
	}
	.ant-switch.ant-switch-checked .ant-switch-handle {
		inset-inline-start: calc( 100% - 20px );
	}
	.ant-switch .ant-switch-handle {
		inset-inline-start: 4px;
		width: 16px;
		height: 16px;
		top: 4px;
	}
	.ant-switch-checked .ant-switch-inner {
		color: #ffffff;
	}
	.ant-switch .ant-switch-inner {
		color: #ffffff;
		font-size: 12px;
	}
`;

export const BannerWrapper = styled.div`
	margin-bottom: 20px;
`;

export const CourseSelect = styled( Select )`
	width: 100%;
	min-width: 220px;
`;

export const TicketNameCell = styled.strong`
	color: #111827;
`;

export const SlugCell = styled.code`
	background: #f3f4f6;
	padding: 2px 6px;
	border-radius: 4px;
	font-size: 12px;
	color: #4b5563;
	font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas,
		monospace;
`;
