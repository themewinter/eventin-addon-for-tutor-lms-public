import { useState, useEffect } from '@wordpress/element';
import { __ } from '@wordpress/i18n';

import { getMapping, getCourses, getDiagnostics } from '../../../api/client';
import {
	setPendingMapping,
	setPendingEnabled,
} from '../../../filters/save-middleware';
import { readLiveTickets } from '../utils/read-live-tickets';

/**
 * Loads mapping + courses + diagnostics for the given event and exposes
 * the state needed by the mapping card.
 * @param {number} eventId
 */
export function useMappingData( eventId ) {
	const [ tickets, setTickets ] = useState( () => readLiveTickets() );
	const [ mapping, setMapping ] = useState( {} );
	const [ enabled, setEnabled ] = useState( false );
	const [ courses, setCourses ] = useState( [] );
	const [ diagnostics, setDiagnostics ] = useState( null );
	const [ loading, setLoading ] = useState( true );
	const [ error, setError ] = useState( '' );

	useEffect( () => {
		setLoading( true );
		setError( '' );

		Promise.all( [ getMapping( eventId ), getCourses(), getDiagnostics() ] )
			.then( ( [ map, courseList, diag ] ) => {
				const initialMapping =
					map.mapping && typeof map.mapping === 'object'
						? map.mapping
						: {};
				const initialEnabled = !! map.enabled;

				setPendingMapping( eventId, initialMapping );
				setPendingEnabled( eventId, initialEnabled );

				const live = readLiveTickets();

				setMapping( initialMapping );
				setEnabled( initialEnabled );
				setCourses( Array.isArray( courseList ) ? courseList : [] );
				setDiagnostics( diag );
				setTickets( live.length ? live : map.tickets || [] );
				setLoading( false );
			} )
			.catch( ( err ) => {
				setError(
					err?.message ||
						__( 'Could not load.', 'eventin-addon-for-tutor-lms' )
				);
				setLoading( false );
			} );
	}, [ eventId ] );

	return {
		tickets,
		setTickets,
		mapping,
		setMapping,
		enabled,
		setEnabled,
		courses,
		diagnostics,
		loading,
		error,
	};
}
