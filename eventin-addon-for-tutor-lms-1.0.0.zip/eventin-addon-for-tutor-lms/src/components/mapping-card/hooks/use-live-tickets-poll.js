import { useEffect } from '@wordpress/element';

import { readLiveTickets } from '../utils/read-live-tickets';

/**
 * Eventin's antd form doesn't emit DOM events we can hook; poll cheaply
 * and call onChange whenever the ticket list shape changes.
 * @param {Function} onChange
 */
export function useLiveTicketsPoll( onChange ) {
	useEffect( () => {
		let lastJson = JSON.stringify( readLiveTickets() );
		const iv = window.setInterval( () => {
			const next = readLiveTickets();
			const nextJson = JSON.stringify( next );
			if ( nextJson === lastJson ) return;
			lastJson = nextJson;
			onChange( next );
		}, 750 );
		return () => window.clearInterval( iv );
	}, [ onChange ] );
}
