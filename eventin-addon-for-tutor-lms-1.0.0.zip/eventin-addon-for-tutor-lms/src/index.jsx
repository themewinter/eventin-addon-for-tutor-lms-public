/**
 * Eventin → Tutor LMS bridge — React entry.
 *
 * FluentCRM-style integration:
 *   - UI rendered on the Advanced tab (DOM-injected, since Eventin core
 *     hardcodes the Advanced layout).
 *   - Mapping is mirrored onto window.eventin.EventForm so Eventin's
 *     own form serializer picks it up at submit time.
 *   - apiFetch middleware also splices `tutor_lms_mapping` into the
 *     outgoing PUT/POST eventin/v2/events as a safety net.
 *   - Backend (event-save-bridge.php) hooks `eventin_event_updated` and
 *     pulls the field off the request → post meta.
 *
 * IMPORTANT: We do NOT register a custom createRootURLMiddleware — that
 * would hijack Eventin's apiFetch calls (last middleware wins). Instead
 * we use leading-slash paths like '/eventin-addon-for-tutor-lms/v1/...' which the
 * WP default rootURL middleware handles correctly.
 *
 * @file index.jsx
 */

import { installSaveMiddleware } from './filters/save-middleware';
import { mountAdvancedCard } from './filters/advanced-mount';

const data = window.eventinTutorLMS || {};

if ( data.restNonce ) {
	installSaveMiddleware();
	mountAdvancedCard();
}
