/**
 * apiFetch save middleware + window.eventin.EventForm bridge.
 *
 * - The middleware splices `tutor_lms_mapping` and `tutor_lms_enabled` into
 *   the outgoing eventin/v2/events PUT/POST so the fields ride along inside
 *   the request body that Eventin's own form submit produces.
 * - We additionally mirror the values onto window.eventin.EventForm (Eventin
 *   exposes the antd Form globally) so Eventin's own form.getFieldsValue()
 *   naturally includes our fields at submit time — matching how FluentCRM works.
 *
 * The PHP side (event-save-bridge.php) hooks `eventin_event_updated` and
 * pulls the fields off the request → post meta.
 */

import apiFetch from '@wordpress/api-fetch';

const _state = { byEventId: {}, enabledByEventId: {} };

function readEventIdFromHash() {
	// NOTE: this regex couples to Eventin's React router shape
	// (`#/events/edit/{id}/...`). If Eventin restructures its routes the
	// middleware silently no-ops and the mapping won't be persisted via
	// this path — the dedicated REST endpoint still works as a fallback.
	const m = ( window.location.hash || '' ).match( /\/events\/edit\/(\d+)/ );
	return m ? parseInt( m[ 1 ], 10 ) : 0;
}

export function getPendingMapping( eventId ) {
	return _state.byEventId[ eventId ] || null;
}

export function setPendingMapping( eventId, mapping ) {
	_state.byEventId[ eventId ] = mapping;

	try {
		const form = window.eventin?.EventForm;
		if ( form && typeof form.setFieldsValue === 'function' ) {
			form.setFieldsValue( { tutor_lms_mapping: mapping } );
		}
	} catch ( e ) {
		/* form not ready yet */
	}
}

export function getPendingEnabled( eventId ) {
	return Object.prototype.hasOwnProperty.call(
		_state.enabledByEventId,
		eventId
	)
		? _state.enabledByEventId[ eventId ]
		: null;
}

export function setPendingEnabled( eventId, enabled ) {
	const value = !! enabled;
	_state.enabledByEventId[ eventId ] = value;

	try {
		const form = window.eventin?.EventForm;
		if ( form && typeof form.setFieldsValue === 'function' ) {
			form.setFieldsValue( { tutor_lms_enabled: value ? 1 : 0 } );
		}
	} catch ( e ) {
		/* form not ready yet */
	}
}

export function installSaveMiddleware() {
	apiFetch.use( ( options, next ) => {
		const method = ( options?.method || 'GET' ).toUpperCase();
		const path = options?.path || options?.url || '';

		if (
			( method === 'POST' || method === 'PUT' ) &&
			/\/eventin\/v2\/events(\/|\?|$)/.test( String( path ) )
		) {
			const eventId = readEventIdFromHash();
			const map = eventId && _state.byEventId[ eventId ];
			const enabled =
				eventId &&
				Object.prototype.hasOwnProperty.call(
					_state.enabledByEventId,
					eventId
				)
					? _state.enabledByEventId[ eventId ]
					: undefined;

			const extra = {};
			if ( map ) {
				extra.tutor_lms_mapping = map;
			}
			if ( typeof enabled === 'boolean' ) {
				extra.tutor_lms_enabled = enabled ? 1 : 0;
			}

			if ( Object.keys( extra ).length ) {
				options = {
					...options,
					data: { ...( options.data || {} ), ...extra },
				};
			}
		}

		return next( options );
	} );
}
