/**
 * Mount the Tutor LMS mapping section inside Eventin's Third-Party
 * Integrations card on the Advanced tab.
 *
 * Eventin's Advanced layout is hardcoded React (no JS filter is exposed),
 * so we inject directly into `#etn-third-party-integrations .ant-card-body`
 * via a debounced MutationObserver. Rendered as inline content alongside
 * FluentCRM — no extra card chrome.
 */

import { createElement, createRoot, render } from '@wordpress/element';

import MappingCard from '../components/mapping-card';

const MOUNT_ID = 'evtn-tutor-mount';

let renderedFor = 0;
let rafHandle = 0;

function isAdvancedTab() {
	return /\/events\/edit\/\d+\/advanced(\/|$|\?)/.test(
		window.location.hash || ''
	);
}

function findAdvancedAnchor() {
	const card = document.getElementById( 'etn-third-party-integrations' );
	if ( card ) {
		const body = card.querySelector( '.ant-card-body' );
		if ( body ) return { node: body, position: 'append' };
	}

	const headings = document.querySelectorAll(
		'.create-event-page h3, .create-event-page h2'
	);
	for ( const heading of headings ) {
		if (
			/third[-\s]?party integrations|integration/i.test(
				heading.textContent || ''
			)
		) {
			const parentCard = heading.closest( '.ant-card' );
			const body = parentCard?.querySelector( '.ant-card-body' );
			if ( body ) return { node: body, position: 'append' };
		}
	}

	return null;
}

function ensureMountNode( anchor ) {
	const existing = document.getElementById( MOUNT_ID );
	if ( existing ) {
		if ( existing.parentNode !== anchor.node ) {
			anchor.node.appendChild( existing );
		}
		return existing;
	}

	const node = document.createElement( 'div' );
	node.id = MOUNT_ID;
	node.className = 'evtn-tutor-mount';
	anchor.node.appendChild( node );
	return node;
}

function rootFor( node ) {
	if ( createRoot ) {
		if ( ! node.__evtnRoot ) {
			node.__evtnRoot = createRoot( node );
		}
		return {
			render: ( v ) => node.__evtnRoot.render( v ),
			unmount: () => {
				try {
					node.__evtnRoot.unmount();
				} catch ( e ) {}
				delete node.__evtnRoot;
			},
		};
	}
	return {
		render: ( v ) => render( v, node ),
		unmount: () => {},
	};
}

function teardown() {
	const existing = document.getElementById( MOUNT_ID );
	if ( ! existing ) return;
	rootFor( existing ).unmount();
	existing.parentNode?.removeChild( existing );
	renderedFor = 0;
}

function mount() {
	if ( ! isAdvancedTab() ) {
		teardown();
		return;
	}

	const match = ( window.location.hash || '' ).match(
		/\/events\/edit\/(\d+)/
	);
	if ( ! match ) {
		teardown();
		return;
	}

	const anchor = findAdvancedAnchor();
	if ( ! anchor ) return;
	const eventId = parseInt( match[ 1 ], 10 );

	const node = ensureMountNode( anchor );

	if ( renderedFor !== eventId ) {
		rootFor( node ).render( createElement( MappingCard, { eventId } ) );
		renderedFor = eventId;
	}
}

function scheduleMount() {
	if ( rafHandle ) return;
	rafHandle = window.requestAnimationFrame( () => {
		rafHandle = 0;
		mount();
	} );
}

export function mountAdvancedCard() {
	const init = () => {
		scheduleMount();
		window.addEventListener( 'hashchange', () => {
			renderedFor = 0;
			scheduleMount();
		} );

		const obs = new MutationObserver( () => {
			scheduleMount();
		} );
		obs.observe( document.body, { childList: true, subtree: true } );
	};

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
}
