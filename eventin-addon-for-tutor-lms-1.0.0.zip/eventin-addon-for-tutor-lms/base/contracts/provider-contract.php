<?php
/**
 * Provider contract.
 *
 * @package Eventin_Tutor/Contracts
 */

namespace Eventin_Tutor\Contracts;

defined( 'ABSPATH' ) || exit;

interface Provider_Contract {
    /**
     * Register providers.
     *
     * @return void
     */
    public function register();

    /**
     * Boot providers.
     *
     * @return void
     */
    public function boot();
}
