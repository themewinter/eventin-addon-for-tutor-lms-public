<?php
/**
 * Contract every hookable service must implement. Mirrors Booktics.
 *
 * @package Eventin_Tutor/Contracts
 */

namespace Eventin_Tutor\Contracts;

defined( 'ABSPATH' ) || exit;

interface Hookable_Service_Contract {
    /**
     * Register hooks for the service.
     *
     * @return void
     */
    public function register();
}
