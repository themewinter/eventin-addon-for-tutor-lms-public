<?php
/**
 * Base service provider abstract. Mirrors the Booktics base provider.
 *
 * @package Eventin_Tutor/Providers
 */

namespace Eventin_Tutor\Providers;

defined( 'ABSPATH' ) || exit;

use Eventin_Tutor\Container\Container;

abstract class Base_Service_Provider {

    /**
     * Container.
     *
     * @var Container
     */
    protected Container $container;

    /**
     * Constructor.
     */
    public function __construct() {
        $this->container = eventin_tutor_container();
        $this->register();
    }

    /**
     * Register all services in this provider.
     *
     * @return void
     */
    public function register() {
        $services = $this->get_services();

        if ( $services ) {
            foreach ( $services as $service ) {
                $object = new $service();

                if ( method_exists( $object, 'register' ) ) {
                    $object->register();
                }
            }
        }
    }

    /**
     * Services declared by the concrete provider.
     *
     * @return array
     */
    abstract public function get_services();
}
