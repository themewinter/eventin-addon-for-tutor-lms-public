<?php
/**
 * Global service provider responsible for registering and booting every module.
 *
 * @package Eventin_Tutor/Providers
 */

namespace Eventin_Tutor\Providers;

defined( 'ABSPATH' ) || exit;

use Eventin_Tutor\Admin\Admin_Service_Provider;
use Eventin_Tutor\Assets\Assets_Service_Provider;
use Eventin_Tutor\Container\Container;
use Eventin_Tutor\Contracts\Provider_Contract;
use Eventin_Tutor\Enrollment\Enrollment_Service_Provider;
use Eventin_Tutor\Rest\Rest_Service_Provider;
use Eventin_Tutor\Settings\Settings_Service_Provider;
use Eventin_Tutor\User\User_Service_Provider;

class Global_Service_Provider implements Provider_Contract {

    /**
     * Container.
     *
     * @var Container
     */
    protected Container $container;

    /**
     * Service providers map.
     *
     * @var array<string, string>
     */
    protected array $providers = array(
        'assets'     => Assets_Service_Provider::class,
        'admin'      => Admin_Service_Provider::class,
        'settings'   => Settings_Service_Provider::class,
        'user'       => User_Service_Provider::class,
        'rest'       => Rest_Service_Provider::class,
        'enrollment' => Enrollment_Service_Provider::class,
    );

    public function __construct() {
        $this->container = eventin_tutor_container();
        $this->register();
        $this->boot();
    }

    /**
     * Register every provider against the container.
     *
     * @return void
     */
    public function register() {
        $providers = apply_filters( 'eventin_tutor_service_providers', $this->providers );

        foreach ( $providers as $key => $provider ) {
            $this->container->add_service_provider( $key, $provider );
        }
    }

    /**
     * Boot every provider that was registered against the container.
     *
     * Iterates `$this->providers` so the `eventin_tutor_service_providers`
     * filter applied in `register()` also affects what gets booted.
     *
     * @return void
     */
    public function boot(): void {
        $services = apply_filters( 'eventin_tutor_services', array_keys( $this->providers ) );

        foreach ( $services as $service ) {
            $this->container->get( $service );
        }
    }
}
