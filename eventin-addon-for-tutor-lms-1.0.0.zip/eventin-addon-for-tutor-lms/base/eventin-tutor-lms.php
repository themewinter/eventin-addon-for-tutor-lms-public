<?php
/**
 * Eventin_Tutor main class — boots the container, loads text domain.
 *
 * @package Eventin_Tutor
 */

namespace Eventin_Tutor;

defined( 'ABSPATH' ) || exit;

use Eventin_Tutor\Container\Container;

class Eventin_Tutor {

    /** @var string */
    public $version;

    /** @var string Absolute path to the main plugin file. */
    public $plugin_file;

    /** @var string Absolute plugin directory path. */
    public $plugin_directory;

    /** @var string e.g. eventin-addon-for-tutor-lms/eventin-addon-for-tutor-lms.php */
    public $basename;

    /** @var string Plugin URL (no trailing slash). */
    public $plugin_url;

    /** @var Container */
    public $container;

    public function __construct() {
        $this->version          = EVENTIN_TUTOR_VERSION;
        $this->plugin_file      = EVENTIN_TUTOR_FILE;
        $this->plugin_directory = EVENTIN_TUTOR_DIR;
        $this->basename         = plugin_basename( $this->plugin_file );
        $this->plugin_url       = plugins_url( '', $this->plugin_file );

        add_action( 'init', array( $this, 'init_classes' ) );
    }

    /**
     * Boot the global service provider — registers + boots every module.
     */
    public function init_classes(): void {
        $this->get_container()->get( 'global' );
    }

    public function get_container(): Container {
        return eventin_tutor_container();
    }

    public static function instance(): Eventin_Tutor {
        static $instance = false;

        if ( ! $instance ) {
            $instance = new self();
        }

        return $instance;
    }
}
