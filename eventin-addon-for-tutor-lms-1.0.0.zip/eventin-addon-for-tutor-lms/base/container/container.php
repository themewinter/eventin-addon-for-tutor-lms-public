<?php
/**
 * Lightweight DI container. Mirrors the Booktics container.
 *
 * @package Eventin_Tutor/Container
 */

namespace Eventin_Tutor\Container;

defined( 'ABSPATH' ) || exit;

use Exception;
use ReflectionClass;
use ReflectionException;
use ReflectionParameter;

class Container {

    /**
     * Registered service providers.
     *
     * @var array<string, string>
     */
    protected $services = array();

    /**
     * Resolve a service by key.
     *
     * @param string $key Service key.
     *
     * @return object
     * @throws Exception When service is missing.
     */
    public function get( string $key ): object {
        if ( ! $this->has( $key ) ) {
            /* translators: %s: service provider name */
            throw new Exception( sprintf( esc_html__( 'Service provider %s not found.', 'eventin-addon-for-tutor-lms' ), esc_html( $key ) ) );
        }

        return $this->resolve( $this->services[ $key ] );
    }

    /**
     * Register a service provider class against a key.
     *
     * @param string $key
     * @param string $class_name
     *
     * @return void
     */
    public function add_service_provider( string $key, string $class_name ): void {
        $this->services[ $key ] = $class_name;
    }

    /**
     * Whether a key is registered.
     *
     * @param string $key
     * @return bool
     */
    public function has( string $key ): bool {
        return array_key_exists( $key, $this->services );
    }

    /**
     * Resolve a class by FQN, recursively building constructor deps.
     *
     * @param string $class_name
     * @return object
     * @throws Exception
     */
    public function resolve( string $class_name ): object {
        if ( ! class_exists( $class_name ) ) {
            /* translators: %s: PHP class name */
            throw new Exception( sprintf( esc_html__( 'Class: %s does not exist.', 'eventin-addon-for-tutor-lms' ), esc_html( $class_name ) ) );
        }

        $reflection_class = new ReflectionClass( $class_name );

        if ( ! $reflection_class->isInstantiable() ) {
            /* translators: %s: PHP class name */
            throw new Exception( sprintf( esc_html__( 'Class: %s is not instantiable.', 'eventin-addon-for-tutor-lms' ), esc_html( $class_name ) ) );
        }

        if ( null === $reflection_class->getConstructor() ) {
            return $reflection_class->newInstance();
        }

        $parameters   = $reflection_class->getConstructor()->getParameters();
        $dependencies = $this->build_dependencies( $parameters );

        return $reflection_class->newInstanceArgs( $dependencies );
    }

    /**
     * Build constructor dependencies.
     *
     * @param ReflectionParameter[] $parameters
     * @return array
     * @throws Exception|ReflectionException
     */
    public function build_dependencies( array $parameters ): array {
        $dependencies = array();

        foreach ( $parameters as $parameter ) {
            $dependency = $parameter->getType() ? $parameter->getType()->getName() : null;

            if ( null === $dependency ) {
                if ( $parameter->isDefaultValueAvailable() ) {
                    $dependencies[] = $parameter->getDefaultValue();
                } else {
                    /* translators: %s: PHP constructor parameter name */
                    throw new Exception( sprintf( esc_html__( 'Class: %s dependency cannot be resolved.', 'eventin-addon-for-tutor-lms' ), esc_html( $parameter->name ) ) );
                }
            } else {
                $dependencies[] = $this->get( $dependency );
            }
        }

        return $dependencies;
    }
}
