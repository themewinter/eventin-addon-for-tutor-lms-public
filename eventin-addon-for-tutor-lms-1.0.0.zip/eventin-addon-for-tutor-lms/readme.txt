=== Eventin Addon for Tutor LMS ===
Contributors: arraytics
Tags: eventin, tutor-lms, enrollment, courses, integration
Requires at least: 5.6
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Auto-enroll Eventin ticket buyers and attendees into mapped Tutor LMS courses.

== Description ==

This addon connects Eventin event ticket purchases to Tutor LMS course enrollment.

After you map an Eventin event’s ticket types to one or more Tutor LMS courses, the plugin will automatically enroll the purchaser (or all registered attendees) when the order is completed.

Features:

* Ticket-type → course mapping per event (supports multiple courses per ticket)
* Option to enroll purchaser only, or all registered attendees
* Optional auto-creation of WordPress user accounts for guest attendees
* Optional unenroll on refund/cancellation/failure

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/`.
2. Activate the plugin through the “Plugins” screen in WordPress.
3. Ensure Eventin and Tutor LMS are installed and active.
4. Go to Eventin → Tutor LMS (or Settings → Tutor LMS Integration, depending on your menu setup) to configure options.
5. Edit an Eventin event and use the “Tutor LMS Course Mapping” box to map ticket types to courses.

== Frequently Asked Questions ==

= Does this plugin require Eventin and Tutor LMS? =

Yes. This addon requires both Eventin and Tutor LMS to be installed and active.

= Who gets enrolled? =

You can choose to enroll only the purchaser, or every registered attendee (Settings → “Who gets enrolled?”).

= Does it create WordPress user accounts automatically? =

Optionally. If enabled, guest attendees are created as WordPress users and can then be enrolled in Tutor LMS.

== External Services ==

This plugin does not send data to external services.

== Development / Build ==

This plugin ships with compiled JavaScript in `build/index.js`, produced from
the human-readable React/JSX sources in `src/` that are included alongside the
compiled bundle in the plugin ZIP.

Build tooling: `@wordpress/scripts` (webpack) is the only JS bundler.
`Gruntfile.js` is an optional orchestrator that runs lint/phpcs/i18n checks
and packages a distributable zip — it does not transform source code.

To rebuild from source:

1. `npm install`
2. `npm run build:js`  (writes `build/index.js` and `build/index.asset.php`)

Source layout:

* `src/index.jsx` — bundle entry, registers the React mapping panel
* `src/components/` — React components rendered into the Eventin admin
* `src/api/` — REST client wrapper
* `src/filters/` — WordPress JS hook registrations

Build configuration (not part of the runtime source):

* `package.json` — npm scripts and dev dependencies
* `Gruntfile.js` — release orchestration (lint, phpcs, zip)

No third-party libraries are bundled beyond the WordPress core packages that
`@wordpress/scripts` externalises (declared in `build/index.asset.php`).

== Changelog ==

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 1.0.0 =
Initial release.
